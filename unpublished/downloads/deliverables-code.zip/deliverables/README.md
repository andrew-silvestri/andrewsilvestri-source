# Final deliverables

Three items, all built from the same calibrated model (7,192 nodes, 13,826
links, every parameter from a public data set).

| # | Item | File | How to make it |
|---|---|---|---|
| 1 | Comprehensive chart | `out/energy_model_chart.png` | `python3 make_chart.py` |
| 1b | Throughline chart | `out/energy_model_throughlines.png` | `python3 make_throughlines.py` |
| 2 | Interactive terminal application | `energy_terminal.py` | `python3 energy_terminal.py` |
| 3 | Technical report | `TECHNICAL_REPORT.md` | Paste into WordPress |

Both charts are also written as `.svg` for clean scaling on the web.

## 1. The charts

**`energy_model_chart.png`** has ten panels: the structure diagram, the node
census, the data sources, the network itself, the weight distribution, the
inertia by node type, the reach of six changes, one change in detail, the
arrival times, and the source table.

**`energy_model_throughlines.png`** traces the routes: the main paths through
the system, five computed end-to-end routes with their strengths, the links that
carry the most influence, one change step by step, a reach matrix, and the same
chain written in words.

## 2. The terminal application

```
python3 energy_terminal.py
```

Commands:

| Command | What it does |
|---|---|
| `find <text>` | search the 7,192 nodes |
| `show <id>` | one node, its links, its data source |
| `scenarios` / `run <name>` | the six ready-made changes |
| `shock <id> [size]` / `go` | your own change |
| `top [n]` | the nodes that changed most |
| `layers` | effect by node type, with bars |
| `path <id>` | the strongest route from the change to that node |
| `watch <id>` | one node, step by step |
| `compare <a> <b>` | two scenarios side by side |
| `export <file.csv>` | save the result |
| `sources` / `kinds` | provenance and census |

It uses only the Python standard library. Colour turns off automatically if the
terminal does not support it.

**Good screenshots for the site:** `run oil_supply_shock` then `layers`;
`run climate_forcing` then `path CON_USA_1_household`; `compare
oil_supply_shock climate_forcing`.

## 3. The technical report

`TECHNICAL_REPORT.md` is written in Simplified Technical English. It covers what
the model does, what it contains, where every number comes from, the calculation,
the full weight table, the inertia table, the fan-in rule, the measured
behaviour, and a numbered list of limits.

Paste the Markdown into a WordPress block editor. The headings and tables
convert directly.

## Rebuilding everything

```
cd "../17 Julia Model/calibrate"
python3 extract_calibration.py      # reads the 11.5 GB of feedstocks
cd "../../18 Final Deliverables"
python3 make_chart.py
python3 make_throughlines.py
python3 energy_terminal.py
```
