#!/usr/bin/env python3
"""
THE WORLD ENERGY MODEL — interactive terminal application.

Same model as the Julia core and the charts: 7,192 nodes built from real data.
Runs in any terminal. No packages beyond the Python standard library.

    python3 energy_terminal.py

Type `help` at the prompt for the command list.
"""
import os, sys, math, csv, time, shutil, textwrap
from collections import Counter, defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(HERE), "17 Julia Model", "calibrate"))
import verify_parity as M

# ── colour, disabled automatically when the terminal does not support it ──────
def _supports_colour():
    if os.environ.get("NO_COLOR"):
        return False
    if sys.platform == "win32":
        return os.environ.get("WT_SESSION") or os.environ.get("TERM_PROGRAM") \
            or "ANSICON" in os.environ or sys.getwindowsversion().major >= 10
    return sys.stdout.isatty()

C_ON = _supports_colour()
def c(code, s):
    return f"\033[{code}m{s}\033[0m" if C_ON else s
BOLD = lambda s: c("1", s)
DIM = lambda s: c("2", s)
RED = lambda s: c("31", s)
GRN = lambda s: c("32", s)
YEL = lambda s: c("33", s)
BLU = lambda s: c("34", s)
CYN = lambda s: c("36", s)

KIND_COLOUR = {"market": "33", "climate": "34", "grid": "32", "supply": "35",
               "district": "36", "consumer": "35", "event": "31",
               "station": "34", "psych": "33"}
KIND_LABEL = {"market": "price benchmark", "climate": "climate system",
              "grid": "national grid", "supply": "fuel supply",
              "district": "district", "consumer": "consumer group",
              "event": "historical event", "station": "power station",
              "psych": "behaviour channel"}


def width():
    return min(shutil.get_terminal_size((100, 30)).columns, 118)


def rule(ch="─"):
    return DIM(ch * width())


def bar(value, vmax, cells=28, positive="█", negative="▓"):
    if vmax <= 0:
        return ""
    n = int(round(abs(value) / vmax * cells))
    ch = positive if value >= 0 else negative
    return (GRN if value >= 0 else RED)(ch * max(n, 1 if abs(value) > 0 else 0))


class App:
    def __init__(self):
        t0 = time.time()
        print(DIM("building the model from calibrated data ..."))
        self.web = M.build()
        self.n = len(self.web["ids"])
        self.build_time = time.time() - t0
        self.state = None
        self.hit = None
        self.shocks = {}
        self.last_name = ""
        self.adj_out = defaultdict(list)
        self.adj_in = defaultdict(list)
        for a, b, w in self.web["edges"]:
            self.adj_out[a].append((b, w))
            self.adj_in[b].append((a, w))

    # ── display helpers ──────────────────────────────────────────────────────
    def node_line(self, i, value=None, rnd=None):
        w = self.web
        k = w["kinds"][i]
        tag = c(KIND_COLOUR.get(k, "37"), f"{KIND_LABEL[k]:<17}")
        nm = w["names"][i][:46]
        out = f"  {tag} {nm:<46}"
        if value is not None:
            out += f" {value:+.4f} "
            out += bar(value, 1.0, 16)
            if rnd is not None and rnd >= 0:
                out += DIM(f"  step {rnd}")
        return out

    def banner(self):
        print()
        print(BOLD("  THE WORLD ENERGY MODEL"))
        print(f"  {self.n:,} nodes · {len(self.web['edges']):,} weighted links · "
              f"built in {self.build_time:.1f} s")
        counts = Counter(self.web["kinds"])
        parts = [c(KIND_COLOUR[k], f"{v:,} {KIND_LABEL[k]}")
                 for k, v in counts.most_common()]
        print(DIM("  ") + DIM(" · ").join(parts))
        print(rule())
        print(DIM("  Type a command. `help` lists them. `quit` exits."))
        print()

    # ── commands ─────────────────────────────────────────────────────────────
    def cmd_help(self, *_):
        print(f"""
{BOLD('  MOVING AROUND')}
  find <text>            search nodes by name or id
  show <id>              show one node, its links, and its data source
  kinds                  list the node types and how many of each
  sources                show where the numbers come from

{BOLD('  RUNNING A CHANGE')}
  scenarios              list the ready-made changes
  run <scenario>         run a ready-made change
  shock <id> [size]      set your own change (size -1 to 1, default 0.8)
  clear                  remove all staged changes
  go                     run the staged changes

{BOLD('  READING THE RESULT')}
  top [n]                the nodes that changed the most
  layers                 the effect on each node type
  path <id>              the strongest route from the change to that node
  compare <a> <b>        run two scenarios and compare them
  watch <id>             show one node step by step

{BOLD('  OTHER')}
  export <file.csv>      save the last result
  help                   this list
  quit                   exit
""")

    def cmd_kinds(self, *_):
        counts = Counter(self.web["kinds"])
        print()
        for k, v in counts.most_common():
            print(f"  {c(KIND_COLOUR[k], KIND_LABEL[k]):<28} {v:>6,}")
        print(f"  {'total':<19} {self.n:>6,}")
        print()

    def cmd_sources(self, *_):
        prov = Counter()
        for p in self.web["prov"]:
            key = ("EIA bulk archive" if p.startswith("EIA") else
                   "EM-DAT disasters" if p.startswith("EM-DAT") else
                   "EI Review / Our World in Data" if p.startswith("EI/OWID") else
                   "FRED price histories" if p.startswith("FRED") else
                   "NOAA / NASA climate" if p.startswith(("NOAA", "NASA")) else
                   "Allen Brain Atlas" if p.startswith("Allen") else
                   "Published studies" if "elasticity" in p else
                   "Derived from the above")
            prov[key] += 1
        print()
        mx = max(prov.values())
        for k, v in prov.most_common():
            print(f"  {k:<32} {v:>6,}  {BLU('█' * int(v / mx * 24))}")
        print()

    def cmd_find(self, *args):
        q = " ".join(args).lower()
        if not q:
            print(DIM("  usage: find <text>")); return
        hits = [i for i in range(self.n)
                if q in self.web["ids"][i].lower() or q in self.web["names"][i].lower()]
        print()
        for i in hits[:30]:
            print(f"  {CYN(self.web['ids'][i]):<40} {self.web['names'][i][:52]}")
        print(DIM(f"  {len(hits)} matches" + (", showing 30" if len(hits) > 30 else "")))
        print()

    def cmd_show(self, *args):
        if not args:
            print(DIM("  usage: show <id>")); return
        nid = args[0]
        i = self.web["idx"].get(nid)
        if i is None:
            print(RED(f"  no node called {nid}")); return
        w = self.web
        print()
        print(f"  {BOLD(w['names'][i])}")
        print(f"  {DIM('id')}         {w['ids'][i]}")
        print(f"  {DIM('type')}       {c(KIND_COLOUR[w['kinds'][i]], KIND_LABEL[w['kinds'][i]])}")
        print(f"  {DIM('inertia')}    {w['res'][i]:.2f}   "
              f"{DIM('(0 reacts at once, 1 very slow)')}")
        print(f"  {DIM('source')}     {w['prov'][i] or 'derived'}")
        if self.state is not None:
            print(f"  {DIM('now')}        {self.state[i]:+.4f}  {bar(self.state[i], 1.0, 20)}")
        outs = sorted(self.adj_out[i], key=lambda t: -abs(t[1]))[:8]
        ins = sorted(self.adj_in[i], key=lambda t: -abs(t[1]))[:8]
        if outs:
            print(f"\n  {BOLD('sends to')}")
            for j, wt in outs:
                sign = GRN("+") if wt >= 0 else RED("-")
                print(f"    {sign}{abs(wt):.3f}  {w['names'][j][:56]}")
        if ins:
            print(f"\n  {BOLD('receives from')}")
            for j, wt in ins:
                sign = GRN("+") if wt >= 0 else RED("-")
                print(f"    {sign}{abs(wt):.3f}  {w['names'][j][:56]}")
        print()

    def cmd_scenarios(self, *_):
        print()
        desc = {
            "oil_supply_shock": "A large oil supply loss raises the crude price.",
            "gas_price_spike": "A gas price spike moves power costs everywhere.",
            "climate_forcing": "The climate system moves to a higher anomaly.",
            "us_grid_stress": "The United States grid loses reserve margin.",
            "china_coal_cut": "China loses part of its coal supply.",
            "behaviour_shift": "A conservation wave enters through behaviour.",
        }
        for k in M.SCEN:
            print(f"  {CYN(k):<24} {desc.get(k, '')}")
        print()

    def cmd_run(self, *args):
        if not args:
            print(DIM("  usage: run <scenario>")); return
        name = args[0]
        if name not in M.SCEN:
            print(RED("  unknown scenario. type `scenarios`.")); return
        self.shocks = dict(M.SCEN[name])
        self.last_name = name
        self._go()

    def cmd_shock(self, *args):
        if not args:
            print(DIM("  usage: shock <id> [size]")); return
        nid = args[0]
        if nid not in self.web["idx"]:
            print(RED(f"  no node called {nid}. try `find`.")); return
        size = float(args[1]) if len(args) > 1 else 0.8
        self.shocks[nid] = size
        print(f"  staged {CYN(nid)} at {size:+.2f}  "
              f"({len(self.shocks)} staged; type `go`)")

    def cmd_clear(self, *_):
        self.shocks = {}
        print(DIM("  staged changes cleared"))

    def cmd_go(self, *_):
        if not self.shocks:
            print(DIM("  nothing staged. use `shock` or `run`.")); return
        self.last_name = self.last_name or "custom"
        self._go()

    def _go(self):
        t0 = time.time()
        self.state, self.hit = M.propagate(self.web, self.shocks)
        touched = sum(1 for x in self.state if abs(x) >= 0.02)
        print()
        print(f"  {BOLD(self.last_name)} — {touched:,} of {self.n:,} nodes changed "
              f"{DIM(f'({time.time()-t0:.2f} s)')}")
        print(rule())
        self.cmd_top("8")

    def cmd_top(self, *args):
        if self.state is None:
            print(DIM("  run something first")); return
        k = int(args[0]) if args and args[0].isdigit() else 15
        order = sorted(range(self.n), key=lambda i: -abs(self.state[i]))
        shown = 0
        print()
        for i in order:
            if self.web["ids"][i] in self.shocks or abs(self.state[i]) < 1e-4:
                continue
            print(self.node_line(i, self.state[i], self.hit[i]))
            shown += 1
            if shown >= k:
                break
        print()

    def cmd_layers(self, *_):
        if self.state is None:
            print(DIM("  run something first")); return
        byk = defaultdict(list)
        for i, kk in enumerate(self.web["kinds"]):
            byk[kk].append(abs(self.state[i]))
        rows = sorted(byk.items(), key=lambda kv: -sum(kv[1]) / len(kv[1]))
        mx = max(sum(v) / len(v) for _, v in rows) or 1
        print()
        print(f"  {'type':<20}{'nodes':>8}{'changed':>9}{'average':>10}")
        print(rule())
        for k, v in rows:
            avg = sum(v) / len(v)
            ch = sum(1 for x in v if x >= 0.02)
            print(f"  {c(KIND_COLOUR[k], KIND_LABEL[k]):<29}{len(v):>8,}{ch:>9,}"
                  f"{avg:>10.4f}  {BLU('█' * int(avg / mx * 20))}")
        print()

    def cmd_path(self, *args):
        if not args:
            print(DIM("  usage: path <id>")); return
        if not self.shocks:
            print(DIM("  stage or run a change first")); return
        import heapq
        target = self.web["idx"].get(args[0])
        if target is None:
            print(RED("  unknown node")); return
        best_overall = (None, 0.0)
        for src in self.shocks:
            s = self.web["idx"].get(src)
            if s is None:
                continue
            best = {s: 1.0}; prev = {}
            pq = [(-1.0, 0, s)]
            while pq:
                negp, hops, u = heapq.heappop(pq)
                p = -negp
                if u == target or hops >= 8 or p < best.get(u, 0) - 1e-12:
                    continue
                for v, wt in self.adj_out[u]:
                    np_ = p * abs(wt)
                    if np_ > best.get(v, 0):
                        best[v] = np_; prev[v] = u
                        heapq.heappush(pq, (-np_, hops + 1, v))
            if target in best and best[target] > best_overall[1]:
                path = [target]
                while path[-1] != s:
                    path.append(prev[path[-1]])
                best_overall = (path[::-1], best[target])
        path, strength = best_overall
        if not path:
            print(RED("  no route found")); return
        print()
        print(f"  strongest route, strength {strength:.4f}")
        for step, i in enumerate(path):
            pad = "  " + "   " * step
            arrow = "" if step == 0 else DIM("└─> ")
            val = f"  {self.state[i]:+.4f}" if self.state is not None else ""
            print(f"{pad}{arrow}{c(KIND_COLOUR[self.web['kinds'][i]], self.web['names'][i][:52])}{DIM(val)}")
        print()

    def cmd_watch(self, *args):
        if not args:
            print(DIM("  usage: watch <id>")); return
        i = self.web["idx"].get(args[0])
        if i is None:
            print(RED("  unknown node")); return
        if not self.shocks:
            print(DIM("  stage or run a change first")); return
        b = [0.0] * self.n
        for k, v in self.shocks.items():
            j = self.web["idx"].get(k)
            if j is not None:
                b[j] = v
        s = b[:]
        gain = [1 - r for r in self.web["res"]]
        series = [s[i]]
        for _ in range(16):
            inf = [0.0] * self.n
            for (a, bb, wt) in self.web["edges"]:
                inf[bb] += wt * s[a]
            s = [(1 - 0.55) * s[q] + 0.55 * math.tanh(b[q] + gain[q] * inf[q])
                 for q in range(self.n)]
            series.append(s[i])
        print()
        print(f"  {BOLD(self.web['names'][i])} — step by step")
        mx = max(abs(x) for x in series) or 1
        for step, v in enumerate(series):
            print(f"   {step:>2}  {v:+.4f}  {bar(v, mx, 42)}")
        print()

    def cmd_compare(self, *args):
        if len(args) < 2:
            print(DIM("  usage: compare <scenario a> <scenario b>")); return
        a, b = args[0], args[1]
        for x in (a, b):
            if x not in M.SCEN:
                print(RED(f"  unknown scenario {x}")); return
        sa, _ = M.propagate(self.web, M.SCEN[a])
        sb, _ = M.propagate(self.web, M.SCEN[b])
        print()
        print(f"  {'type':<20}{a[:14]:>15}{b[:14]:>15}{'difference':>13}")
        print(rule())
        byk = defaultdict(lambda: [0.0, 0.0, 0])
        for i, kk in enumerate(self.web["kinds"]):
            byk[kk][0] += abs(sa[i]); byk[kk][1] += abs(sb[i]); byk[kk][2] += 1
        for k, (ta, tb, cnt) in sorted(byk.items(),
                                       key=lambda kv: -(kv[1][0] + kv[1][1])):
            ma, mb = ta / cnt, tb / cnt
            d = mb - ma
            mark = GRN("▲") if d > 0.001 else (RED("▼") if d < -0.001 else DIM("="))
            print(f"  {c(KIND_COLOUR[k], KIND_LABEL[k]):<29}{ma:>15.4f}{mb:>15.4f}"
                  f"{d:>12.4f} {mark}")
        print()

    def cmd_export(self, *args):
        if self.state is None:
            print(DIM("  run something first")); return
        name = args[0] if args else "result.csv"
        p = os.path.join(HERE, "out", name)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "w", newline="", encoding="utf8") as f:
            wtr = csv.writer(f)
            wtr.writerow(["id", "name", "type", "effect", "step_first_changed",
                          "source"])
            order = sorted(range(self.n), key=lambda i: -abs(self.state[i]))
            for i in order:
                if abs(self.state[i]) < 1e-4:
                    continue
                wtr.writerow([self.web["ids"][i], self.web["names"][i],
                              self.web["kinds"][i], round(self.state[i], 6),
                              self.hit[i], self.web["prov"][i]])
        print(f"  written to {p}")

    # ── loop ─────────────────────────────────────────────────────────────────
    def run(self):
        self.banner()
        cmds = {"help": self.cmd_help, "?": self.cmd_help,
                "find": self.cmd_find, "show": self.cmd_show,
                "kinds": self.cmd_kinds, "sources": self.cmd_sources,
                "scenarios": self.cmd_scenarios, "run": self.cmd_run,
                "shock": self.cmd_shock, "clear": self.cmd_clear,
                "go": self.cmd_go, "top": self.cmd_top,
                "layers": self.cmd_layers, "path": self.cmd_path,
                "watch": self.cmd_watch, "compare": self.cmd_compare,
                "export": self.cmd_export}
        while True:
            try:
                line = input(BOLD("  model> ")).strip()
            except (EOFError, KeyboardInterrupt):
                print(); break
            if not line:
                continue
            parts = line.split()
            cmd, args = parts[0].lower(), parts[1:]
            if cmd in ("quit", "exit", "q"):
                break
            fn = cmds.get(cmd)
            if fn is None:
                print(DIM("  unknown command. type `help`."))
                continue
            try:
                fn(*args)
            except Exception as e:
                print(RED(f"  error: {e}"))
        print(DIM("  closed."))


if __name__ == "__main__":
    App().run()
