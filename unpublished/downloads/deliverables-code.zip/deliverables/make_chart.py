"""
Deliverable 1 — the comprehensive chart.

One publication-quality figure that shows every node class, every data source,
the weight structure, and the behaviour of the model. Built from the calibrated
model, not from a sketch.

    python3 make_chart.py

Writes: out/energy_model_chart.png (and .svg) at 300 dpi.
"""
import os, sys, csv, math, json
from collections import Counter, defaultdict

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle
from matplotlib.lines import Line2D
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(HERE), "17 Julia Model", "calibrate"))
OUT = os.path.join(HERE, "out")
os.makedirs(OUT, exist_ok=True)

import verify_parity as M          # the verified model build

INK = "#1b1b1b"; DIM = "#6d7278"; GRID = "#e6e3de"
KC = {"market": "#c8922f", "climate": "#4f8fbe", "grid": "#4a9a6b",
      "supply": "#b3679b", "district": "#3f9a9a", "consumer": "#8d6fb8",
      "event": "#c0554b", "station": "#4a6fa5", "psych": "#b8994a"}
KIND_LABEL = {"market": "Price benchmark", "climate": "Climate system",
              "grid": "National grid", "supply": "Fuel supply",
              "district": "District", "consumer": "Consumer group",
              "event": "Historical event", "station": "Power station",
              "psych": "Behaviour channel"}


def main():
    web = M.build()
    n = len(web["ids"])
    kinds = web["kinds"]
    counts = Counter(kinds)
    edges = web["edges"]

    # scenario runs
    runs = {}
    for name, sh in M.SCEN.items():
        if all(k in web["idx"] for k in sh):
            s, hit = M.propagate(web, sh)
            runs[name] = (s, hit, sh)

    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 9,
        "axes.edgecolor": "#c9c5be", "axes.labelcolor": INK,
        "text.color": INK, "xtick.color": DIM, "ytick.color": DIM,
        "axes.titlesize": 10.5, "axes.titleweight": "bold",
    })
    fig = plt.figure(figsize=(20, 26), facecolor="white")
    gs = fig.add_gridspec(6, 4, height_ratios=[0.5, 1.25, 1.0, 1.0, 1.0, 0.85],
                          hspace=0.42, wspace=0.28,
                          left=0.05, right=0.97, top=0.965, bottom=0.035)

    # ── title block ──────────────────────────────────────────────────────────
    ax = fig.add_subplot(gs[0, :]); ax.axis("off")
    ax.text(0, 0.78, "THE WORLD ENERGY MODEL", fontsize=27, fontweight="bold",
            color=INK, va="top")
    ax.text(0, 0.30,
            f"{n:,} nodes and {len(edges):,} weighted links. "
            "Every parameter comes from a public data set. "
            "This chart shows what the model contains, how it is weighted, "
            "and how it behaves.",
            fontsize=12.5, color=DIM, va="top")
    ax.text(0, 0.02,
            "Data: Energy Institute Statistical Review · Our World in Data · "
            "EIA bulk archive · FRED · EM-DAT · NOAA · NASA GISTEMP · Allen Brain Atlas",
            fontsize=9.5, color=DIM, va="top", style="italic")
    ax.set_xlim(0, 1); ax.set_ylim(0, 1)

    # ── 1. the layer diagram ─────────────────────────────────────────────────
    ax = fig.add_subplot(gs[1, :2])
    ax.set_title("A.  Structure: how a change moves through the model", loc="left")
    ax.axis("off"); ax.set_xlim(0, 10); ax.set_ylim(0, 10)
    boxes = [
        ("climate", "Climate system\nCO2 and temperature", 0.6, 8.2),
        ("market", "Price benchmarks\noil, gas, power, CPI", 0.6, 6.4),
        ("event", "Historical events\nEM-DAT disasters", 0.6, 4.6),
        ("supply", "Fuel supplies\nper country and fuel", 4.0, 6.4),
        ("grid", "National grids\n214 countries", 4.0, 4.2),
        ("station", "Power stations\nreal US plants", 4.0, 2.0),
        ("district", "Districts\nsub-national demand", 7.3, 4.25),
        ("consumer", "Consumer groups\nhouseholds, industry", 7.4, 2.0),
        ("psych", "Behaviour channels\nbrain-mapped", 7.4, 6.4),
    ]
    pos = {}
    for kind, label, x, y in boxes:
        bw, bh = 2.5, 1.35
        ax.add_patch(FancyBboxPatch((x, y), bw, bh, boxstyle="round,pad=0.08",
                                    linewidth=1.6, edgecolor=KC[kind],
                                    facecolor=KC[kind] + "22"))
        ax.text(x + bw / 2, y + bh / 2 + 0.18, label.split("\n")[0], ha="center",
                va="center", fontsize=9.5, fontweight="bold", color=INK)
        ax.text(x + bw / 2, y + bh / 2 - 0.30, label.split("\n")[1], ha="center",
                va="center", fontsize=8, color=DIM)
        ax.text(x + bw - 0.12, y + bh - 0.16, f"{counts.get(kind,0):,}", ha="right",
                va="top", fontsize=8.5, color=KC[kind], fontweight="bold")
        pos[kind] = (x, y, bw, bh)

    def arrow(a, b, label="", rad=0.0, side="r"):
        xa, ya, wa, ha_ = pos[a]; xb, yb, wb, hb = pos[b]
        if side == "r":
            p1 = (xa + wa, ya + ha_ / 2); p2 = (xb, yb + hb / 2)
        elif side == "d":
            p1 = (xa + wa / 2, ya); p2 = (xb + wb / 2, yb + hb)
        else:
            p1 = (xa + wa / 2, ya + ha_); p2 = (xb + wb / 2, yb)
        ax.add_patch(FancyArrowPatch(p1, p2, arrowstyle="-|>", mutation_scale=13,
                                     linewidth=1.3, color="#8a8f95",
                                     connectionstyle=f"arc3,rad={rad}"))
        if label:
            mx, my = (p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2
            ax.text(mx, my + 0.22, label, ha="center", fontsize=7.6, color=DIM,
                    bbox=dict(fc="white", ec="none", pad=1.2))
    arrow("climate", "market", "", -0.15, "d")
    arrow("market", "supply", "price passes through", 0.0, "r")
    arrow("supply", "grid", "weight = real fuel share", 0.0, "d")
    arrow("event", "grid", "severity from damages", 0.15, "r")
    arrow("station", "grid", "fleet, normalised", 0.0, "u")
    arrow("grid", "district", "", 0.0, "r")
    arrow("district", "consumer", "", 0.0, "d")
    arrow("psych", "consumer", "", -0.2, "d")
    ax.text(7.35, 8.6, "Behaviour changes\nhow much demand reacts",
            fontsize=7.8, color=DIM, va="top")
    ax.text(0.6, 0.75, "Each link carries a signed weight. A change at any node "
            "spreads along the links,\nloses strength at each step, and settles.",
            fontsize=8.6, color=DIM, va="top")

    # ── 2. node census ───────────────────────────────────────────────────────
    ax = fig.add_subplot(gs[1, 2])
    ax.set_title("B.  What the model contains", loc="left")
    order = sorted(counts.items(), key=lambda kv: kv[1])
    ax.barh([KIND_LABEL[k] for k, _ in order], [v for _, v in order],
            color=[KC[k] for k, _ in order], height=0.68)
    for i, (k, v) in enumerate(order):
        ax.text(v * 1.06, i, f"{v:,}", va="center", fontsize=8.5, color=INK)
    ax.set_xscale("log"); ax.set_xlim(0.8, 1e4)
    ax.set_xlabel("nodes (log scale)")
    ax.grid(axis="x", color=GRID, lw=0.7); ax.set_axisbelow(True)
    for sp in ("top", "right"): ax.spines[sp].set_visible(False)

    # ── 3. provenance ────────────────────────────────────────────────────────
    ax = fig.add_subplot(gs[1, 3])
    ax.set_title("C.  Where the numbers come from", loc="left")
    prov = Counter()
    for p in web["prov"]:
        if p.startswith("EIA"): prov["EIA bulk archive"] += 1
        elif p.startswith("EM-DAT"): prov["EM-DAT disasters"] += 1
        elif p.startswith("EI/OWID"): prov["EI Review / OWID"] += 1
        elif p.startswith("FRED"): prov["FRED prices"] += 1
        elif p.startswith("NOAA") or p.startswith("NASA"): prov["NOAA / NASA"] += 1
        elif p.startswith("Allen"): prov["Allen Brain Atlas"] += 1
        elif "elasticity" in p: prov["Literature values"] += 1
        else: prov["Derived from the above"] += 1
    labels = [f"{k}\n{v:,}" for k, v in prov.most_common()]
    vals = [v for _, v in prov.most_common()]
    cols = ["#4a6fa5", "#c0554b", "#4a9a6b", "#c8922f", "#4f8fbe", "#b8994a",
            "#8d6fb8", "#9a9a9a"][:len(vals)]
    wedges, _ = ax.pie(vals, colors=cols, startangle=90, counterclock=False,
                       wedgeprops=dict(width=0.42, edgecolor="white"))
    ax.legend(wedges, [f"{k} — {v:,}" for k, v in prov.most_common()],
              loc="center left", bbox_to_anchor=(0.92, 0.5), frameon=False,
              fontsize=8.2)
    ax.text(0, 0, f"{n:,}\nnodes", ha="center", va="center", fontsize=11,
            fontweight="bold")

    # ── 4. the network itself ────────────────────────────────────────────────
    ax = fig.add_subplot(gs[2:4, :2])
    ax.set_title("D.  The network. Position shows the layer; colour shows the type",
                 loc="left")
    ax.axis("off")
    LAYER_X = {"climate": 0.5, "market": 1.6, "event": 1.6, "supply": 3.0,
               "grid": 4.4, "station": 4.4, "district": 5.8, "consumer": 7.0,
               "psych": 7.0}
    rng = np.random.default_rng(4)
    xy = {}
    per = defaultdict(list)
    for i, k in enumerate(kinds): per[k].append(i)
    for k, ids in per.items():
        x0 = LAYER_X[k]
        m = len(ids)
        ys = np.linspace(0.06, 0.94, m) if m > 1 else np.array([0.5])
        if k in ("station",): ys = ys * 0.42 + 0.02
        elif k in ("grid",): ys = ys * 0.44 + 0.52
        elif k == "event": ys = ys * 0.40 + 0.02
        elif k == "market": ys = ys * 0.30 + 0.62
        elif k == "psych": ys = ys * 0.24 + 0.72
        elif k == "consumer": ys = ys * 0.62 + 0.04
        for i, y in zip(ids, ys):
            xy[i] = (x0 + rng.normal(0, 0.10), y + rng.normal(0, 0.004))
    for (a, b, wgt) in edges[::3]:
        if a in xy and b in xy:
            xa, ya = xy[a]; xb, yb = xy[b]
            ax.plot([xa, xb], [ya, yb], lw=0.25, color="#b9bcc0", alpha=0.32,
                    solid_capstyle="round", zorder=1)
    for k, ids in per.items():
        pts = np.array([xy[i] for i in ids])
        ax.scatter(pts[:, 0], pts[:, 1], s=9 if k == "station" else 22,
                   c=KC[k], alpha=0.9, linewidths=0, zorder=3,
                   label=f"{KIND_LABEL[k]} ({len(ids):,})")
    ax.legend(loc="lower center", ncol=5, frameon=False, fontsize=8.4,
              bbox_to_anchor=(0.5, -0.06))
    ax.set_xlim(-0.2, 8.0); ax.set_ylim(-0.10, 1.02)

    # ── 5. weight distribution ───────────────────────────────────────────────
    ax = fig.add_subplot(gs[2, 2])
    ax.set_title("E.  Link weights", loc="left")
    ws = np.array([w for _, _, w in edges])
    ax.hist(ws[ws > 0], bins=40, color="#4a9a6b", alpha=0.85, label="positive")
    if (ws < 0).any():
        ax.hist(ws[ws < 0], bins=20, color="#c0554b", alpha=0.85, label="negative")
    ax.set_yscale("log"); ax.set_xlabel("weight"); ax.set_ylabel("links")
    ax.legend(frameon=False, fontsize=8)
    ax.grid(axis="y", color=GRID, lw=0.7); ax.set_axisbelow(True)
    for sp in ("top", "right"): ax.spines[sp].set_visible(False)

    # ── 6. inertia by type ───────────────────────────────────────────────────
    ax = fig.add_subplot(gs[2, 3])
    ax.set_title("F.  Inertia: how strongly a node resists change", loc="left")
    data, labs, cols = [], [], []
    for k in sorted(per, key=lambda k: -np.mean([web["res"][i] for i in per[k]])):
        data.append([web["res"][i] for i in per[k]])
        labs.append(KIND_LABEL[k]); cols.append(KC[k])
    bp = ax.boxplot(data, vert=False, tick_labels=labs, patch_artist=True, widths=0.6,
                    medianprops=dict(color=INK, lw=1.2), flierprops=dict(ms=2))
    for patch, c in zip(bp["boxes"], cols):
        patch.set_facecolor(c + "66"); patch.set_edgecolor(c)
    ax.set_xlabel("0 = reacts at once, 1 = very slow")
    ax.grid(axis="x", color=GRID, lw=0.7); ax.set_axisbelow(True)
    for sp in ("top", "right"): ax.spines[sp].set_visible(False)
    ax.tick_params(labelsize=8)

    # ── 7. scenario reach ────────────────────────────────────────────────────
    ax = fig.add_subplot(gs[3, 2:])
    ax.set_title("G.  Six changes, and how far each one spreads", loc="left")
    names = list(runs)
    touched = [sum(1 for x in runs[nm][0] if abs(x) >= 0.02) for nm in names]
    o = np.argsort(touched)
    ax.barh([names[i].replace("_", " ") for i in o], [touched[i] for i in o],
            color="#4a6fa5", height=0.62)
    for j, i in enumerate(o):
        ax.text(touched[i] + n * 0.01, j, f"{touched[i]:,} of {n:,}",
                va="center", fontsize=8.5, color=INK)
    ax.set_xlabel("nodes that change by more than 2 percent")
    ax.set_xlim(0, max(touched) * 1.25)
    ax.grid(axis="x", color=GRID, lw=0.7); ax.set_axisbelow(True)
    for sp in ("top", "right"): ax.spines[sp].set_visible(False)

    # ── 8. one scenario in detail ────────────────────────────────────────────
    ax = fig.add_subplot(gs[4, :2])
    s, hit, sh = runs["oil_supply_shock"]
    ax.set_title("H.  Example: a large oil supply loss. Effect by node type",
                 loc="left")
    byk = defaultdict(list)
    for i, k in enumerate(kinds):
        if abs(s[i]) >= 0.02: byk[k].append(abs(s[i]))
    ks = sorted(byk, key=lambda k: -np.mean(byk[k]))
    ax.bar(range(len(ks)), [np.mean(byk[k]) for k in ks],
           yerr=[np.std(byk[k]) for k in ks], color=[KC[k] for k in ks],
           capsize=3, width=0.62)
    ax.set_xticks(range(len(ks)))
    ax.set_xticklabels([f"{KIND_LABEL[k]}\n{len(byk[k]):,} nodes" for k in ks],
                       fontsize=8)
    ax.set_ylabel("average effect")
    ax.grid(axis="y", color=GRID, lw=0.7); ax.set_axisbelow(True)
    for sp in ("top", "right"): ax.spines[sp].set_visible(False)

    # ── 9. arrival time ──────────────────────────────────────────────────────
    ax = fig.add_subplot(gs[4, 2:])
    ax.set_title("I.  How long the effect takes to arrive", loc="left")
    for k in ks:
        rounds = [hit[i] for i, kk in enumerate(kinds)
                  if kk == k and hit[i] >= 0 and abs(s[i]) >= 0.02]
        if rounds:
            ax.scatter(np.median(rounds), KIND_LABEL[k], s=40 + 4 * len(rounds),
                       color=KC[k], alpha=0.9, zorder=3)
            ax.text(np.median(rounds) + 0.15, KIND_LABEL[k], f"{len(rounds):,}",
                    va="center", fontsize=8, color=DIM)
    ax.set_xlabel("steps until the node first changes")
    ax.grid(axis="x", color=GRID, lw=0.7); ax.set_axisbelow(True)
    for sp in ("top", "right"): ax.spines[sp].set_visible(False)
    ax.tick_params(labelsize=8.5)

    # ── 10. the data table ───────────────────────────────────────────────────
    ax = fig.add_subplot(gs[5, :]); ax.axis("off")
    ax.set_title("J.  The data behind the model", loc="left")
    cal = os.path.join(os.path.dirname(HERE), "17 Julia Model", "calibrate", "out")
    rows = [
        ["Energy Institute Statistical Review", "Fuel mix and demand, every country",
         "299,321 rows, 1965 to 2025", "Grid size, fuel-share weights"],
        ["Our World in Data", "130 energy variables per country",
         "11,285 country-years", "Fuel shares for 182 more countries"],
        ["EIA bulk archive", "US plants and generation",
         "765,756 series; 15,247 plants located", "Station nodes with coordinates"],
        ["FRED", "Daily price histories",
         "9 series, 38,633 observations", "Market inertia from real volatility"],
        ["EM-DAT", "Recorded disasters",
         "27,727 events; 14,057 energy-relevant", "Event nodes; damage sets severity"],
        ["NOAA Mauna Loa", "Carbon dioxide", "820 months", "Climate node state"],
        ["NASA GISTEMP", "Global temperature", "146 years", "Temperature node state"],
        ["Allen Brain Atlas", "Brain structures", "6 channels matched",
         "Behaviour nodes on real anatomy"],
        ["FAOSTAT", "Nitrogen fertilizer use", "12,734 area-years",
         "Held for the agriculture layer"],
    ]
    tbl = ax.table(cellText=rows,
                   colLabels=["Source", "Content", "Size", "Use in the model"],
                   loc="upper left", cellLoc="left", colWidths=[0.22, 0.26, 0.22, 0.30])
    tbl.auto_set_font_size(False); tbl.set_fontsize(8.6); tbl.scale(1, 1.5)
    for (r, c), cell in tbl.get_celld().items():
        cell.set_edgecolor("#dcd9d3")
        if r == 0:
            cell.set_facecolor("#f0ede8"); cell.set_text_props(fontweight="bold")
        elif r % 2 == 0:
            cell.set_facecolor("#fafaf8")

    fig.text(0.05, 0.012,
             "Model built and verified July 2026. Effects are relative, not in "
             "dollars. Consumer response values come from published studies and "
             "are the only assumed parameters.",
             fontsize=8.5, color=DIM)

    p = os.path.join(OUT, "energy_model_chart.png")
    fig.savefig(p, dpi=180, facecolor="white", bbox_inches="tight")
    fig.savefig(p.replace(".png", ".svg"), facecolor="white", bbox_inches="tight")
    plt.close(fig)
    print("wrote", p)
    print("nodes", n, "edges", len(edges))


if __name__ == "__main__":
    main()
