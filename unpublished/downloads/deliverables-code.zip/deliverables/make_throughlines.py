"""
Deliverable 1b — the throughline figure.

Traces the strongest paths through the whole system: from the climate and the
price benchmarks, down through fuel supplies, grids and districts, to the
consumer and the behaviour channels. It also shows which single links carry the
most influence, and how one change travels step by step.

    python3 make_throughlines.py

Writes: out/energy_model_throughlines.png (and .svg)
"""
import os, sys, math, heapq
from collections import defaultdict, Counter

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(HERE), "17 Julia Model", "calibrate"))
OUT = os.path.join(HERE, "out"); os.makedirs(OUT, exist_ok=True)
import verify_parity as M

INK = "#1b1b1b"; DIM = "#6d7278"; GRIDC = "#e6e3de"
KC = {"market": "#c8922f", "climate": "#4f8fbe", "grid": "#4a9a6b",
      "supply": "#b3679b", "district": "#3f9a9a", "consumer": "#8d6fb8",
      "event": "#c0554b", "station": "#4a6fa5", "psych": "#b8994a"}
KIND_LABEL = {"market": "Price benchmark", "climate": "Climate system",
              "grid": "National grid", "supply": "Fuel supply",
              "district": "District", "consumer": "Consumer group",
              "event": "Historical event", "station": "Power station",
              "psych": "Behaviour channel"}
LAYER_ORDER = ["climate", "event", "market", "supply", "station", "grid",
               "district", "consumer", "psych"]


def strongest_path(web, src, dst, maxhop=8):
    """Path that keeps the most influence: maximise the product of |weight|."""
    adj = defaultdict(list)
    for a, b, w in web["edges"]:
        adj[a].append((b, abs(w)))
    s = web["idx"].get(src); t = web["idx"].get(dst)
    if s is None or t is None:
        return None, 0.0
    best = {s: 1.0}; prev = {}
    pq = [(-1.0, 0, s)]
    while pq:
        negp, hops, u = heapq.heappop(pq)
        p = -negp
        if u == t:
            break
        if hops >= maxhop or p < best.get(u, 0) - 1e-12:
            continue
        for v, w in adj[u]:
            np_ = p * w
            if np_ > best.get(v, 0):
                best[v] = np_; prev[v] = u
                heapq.heappush(pq, (-np_, hops + 1, v))
    if t not in best:
        return None, 0.0
    path = [t]
    while path[-1] != s:
        path.append(prev[path[-1]])
    return path[::-1], best[t]


def main():
    web = M.build()
    n = len(web["ids"])
    ids, names, kinds = web["ids"], web["names"], web["kinds"]
    idx = web["idx"]

    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9,
                         "text.color": INK, "axes.titlesize": 10.5,
                         "axes.titleweight": "bold", "xtick.color": DIM,
                         "ytick.color": DIM, "axes.labelcolor": INK,
                         "axes.edgecolor": "#c9c5be"})
    fig = plt.figure(figsize=(20, 23), facecolor="white")
    gs = fig.add_gridspec(5, 3, height_ratios=[0.34, 1.5, 1.05, 1.05, 0.95],
                          hspace=0.40, wspace=0.26, left=0.045, right=0.975,
                          top=0.968, bottom=0.035)

    # ── title
    ax = fig.add_subplot(gs[0, :]); ax.axis("off")
    ax.text(0, 0.75, "THROUGHLINES: FROM THE CLIMATE TO THE MIND", fontsize=25,
            fontweight="bold", va="top")
    ax.text(0, 0.20,
            "The model connects the physical world to human behaviour. "
            "These panels show the strongest routes through the system, "
            "the links that carry the most influence, and how one change moves "
            "step by step.", fontsize=12.5, color=DIM, va="top")
    ax.set_xlim(0, 1); ax.set_ylim(0, 1)

    # ── A. the master throughline diagram ───────────────────────────────────
    ax = fig.add_subplot(gs[1, :])
    ax.set_title("A.  The main routes through the system", loc="left")
    ax.axis("off"); ax.set_xlim(0, 100); ax.set_ylim(0, 46)

    LX = {"climate": 6, "event": 6, "market": 22, "supply": 39, "station": 39,
          "grid": 56, "district": 71, "consumer": 85, "psych": 85}
    LY = {"climate": 37, "event": 12, "market": 25, "supply": 33, "station": 12,
          "grid": 24, "district": 24, "consumer": 14, "psych": 34}
    boxw, boxh = 13.5, 6.2
    for k in LAYER_ORDER:
        x, y = LX[k], LY[k]
        ax.add_patch(FancyBboxPatch((x, y), boxw, boxh, boxstyle="round,pad=0.25",
                                    lw=1.8, edgecolor=KC[k], facecolor=KC[k] + "1e"))
        ax.text(x + boxw / 2, y + boxh - 1.5, KIND_LABEL[k], ha="center",
                fontsize=10.5, fontweight="bold")
        cnt = sum(1 for kk in kinds if kk == k)
        ax.text(x + boxw / 2, y + boxh - 3.5, f"{cnt:,} nodes", ha="center",
                fontsize=8.6, color=DIM)
        ex = {"climate": "CO2 431 ppm, +1.19 C",
              "event": "526 real disasters",
              "market": "Brent, Henry Hub, CPI",
              "supply": "real fuel share sets weight",
              "station": "4,000 located plants",
              "grid": "214 countries",
              "district": "sub-national demand",
              "consumer": "households and industry",
              "psych": "habit, loss, status, norms"}[k]
        ax.text(x + boxw / 2, y + 1.1, ex, ha="center", fontsize=7.8, color=DIM,
                style="italic")

    def link(a, b, label, w, curve=0.0, lift=1.4):
        xa, ya = LX[a] + boxw, LY[a] + boxh / 2
        xb, yb = LX[b], LY[b] + boxh / 2
        if a == b:
            return
        if LX[a] == LX[b]:
            xa, ya = LX[a] + boxw / 2, LY[a]
            xb, yb = LX[b] + boxw / 2, LY[b] + boxh
        ax.add_patch(FancyArrowPatch((xa, ya), (xb, yb), arrowstyle="-|>",
                                     mutation_scale=16, lw=1.0 + 4.5 * w,
                                     color="#7d8489", alpha=0.85,
                                     connectionstyle=f"arc3,rad={curve}"))
        mx, my = (xa + xb) / 2, (ya + yb) / 2 + lift
        ax.text(mx, my, label, ha="center", fontsize=8.1, color=INK,
                bbox=dict(fc="white", ec="#e2ded8", boxstyle="round,pad=0.28"))

    link("climate", "market", "warming shifts prices", 0.30, -0.12)
    link("climate", "grid", "heat and cold stress the grid", 0.30, -0.30, 3.2)
    link("climate", "event", "warming raises event risk", 0.12, 0.0)
    link("event", "grid", "damage takes plants offline", 0.35, 0.16)
    link("market", "supply", "fuel cost passes through", 0.55, 0.0)
    link("supply", "grid", "weight = real fuel share", 0.55, 0.0)
    link("station", "grid", "fleet feeds the grid", 0.45, 0.0)
    link("grid", "district", "power is delivered", 0.60, 0.0)
    link("district", "consumer", "demand is met", 0.50, 0.0)
    link("market", "psych", "price is felt", 0.25, -0.32, 3.0)
    link("psych", "consumer", "behaviour sets the response", 0.12, 0.0)
    ax.annotate("", xy=(LX["district"] + 2, LY["district"]),
                xytext=(LX["consumer"] + 4, LY["consumer"] + boxh),
                arrowprops=dict(arrowstyle="-|>", color="#c0554b", lw=1.6,
                                connectionstyle="arc3,rad=0.3"))
    ax.text(78, 21.5, "demand response\n(negative link)", fontsize=8.1,
            color="#c0554b", ha="center",
            bbox=dict(fc="white", ec="#e8d5d2", boxstyle="round,pad=0.28"))

    # ── B. strongest computed paths ─────────────────────────────────────────
    ax = fig.add_subplot(gs[2, :2])
    ax.set_title("B.  The strongest computed routes, end to end", loc="left")
    ax.axis("off")
    targets = [
        ("CLIMATE_SYS", "PSYCH_habit", "Climate  ->  behaviour"),
        ("CLIMATE_SYS", "CON_USA_1_household", "Climate  ->  a US household"),
        ("MKT_BRENT", "CON_IND_1_household", "Oil price  ->  an Indian household"),
        ("MKT_HH", "CON_DEU_1_industry", "Gas price  ->  German industry"),
        ("PSYCH_norm", "CON_CHN_1_household", "Social norms  ->  a Chinese household"),
    ]
    y = 0.955
    for src, dst, label in targets:
        path, strength = strongest_path(web, src, dst)
        if not path:
            continue
        _pth, _str = strongest_path(web, src, dst)
        ax.text(0.005, y, label, fontsize=10.5, fontweight="bold", va="top")
        ax.text(0.005, y - 0.040, f"route strength {_str:.3f}", fontsize=8.2,
                color=DIM, va="top")
        y -= 0.090
        xs = np.linspace(0.10, 0.94, len(path))
        for j, (nid_i, xx) in enumerate(zip(path, xs)):
            k = kinds[nid_i]
            ax.scatter(xx, y, s=210, color=KC[k], zorder=3, edgecolors="white",
                       linewidths=1.4)
            short = names[nid_i]
            if len(short) > 20:
                short = short[:19] + "."
            ax.text(xx, y - 0.036, short, ha="center", fontsize=7.4, color=INK)
            ax.text(xx, y + 0.026, KIND_LABEL[k], ha="center", fontsize=6.4,
                    color=DIM)
            if j < len(path) - 1:
                ax.annotate("", xy=(xs[j + 1] - 0.012, y), xytext=(xx + 0.012, y),
                            arrowprops=dict(arrowstyle="-|>", color="#9aa0a6",
                                            lw=1.3))
        y -= 0.165
    ax.set_xlim(0, 1); ax.set_ylim(0, 1)

    # ── C. the most influential single links ────────────────────────────────
    ax = fig.add_subplot(gs[2, 2])
    ax.set_title("C.  The links that carry the most influence", loc="left")
    scored = []
    for a, b, w in web["edges"]:
        scored.append((abs(w), a, b, w))
    scored.sort(reverse=True)
    seen = set(); rows = []
    for wabs, a, b, w in scored:
        key = (kinds[a], kinds[b])
        if key in seen:
            continue
        seen.add(key)
        rows.append((f"{KIND_LABEL[kinds[a]]}  ->  {KIND_LABEL[kinds[b]]}", w))
        if len(rows) >= 10:
            break
    rows.reverse()
    ax.barh([r[0] for r in rows], [r[1] for r in rows],
            color=["#c0554b" if r[1] < 0 else "#4a6fa5" for r in rows], height=0.66)
    for i, r in enumerate(rows):
        ax.text(r[1] + 0.012, i, f"{r[1]:.2f}", va="center", fontsize=8)
    ax.set_xlabel("link weight")
    ax.set_xlim(0, max(r[1] for r in rows) * 1.22)
    ax.tick_params(labelsize=7.4)
    ax.grid(axis="x", color=GRIDC, lw=0.7); ax.set_axisbelow(True)
    for sp in ("top", "right"): ax.spines[sp].set_visible(False)

    # ── D. step-by-step spread of one change ────────────────────────────────
    ax = fig.add_subplot(gs[3, :2])
    ax.set_title("D.  One change, step by step: a large oil supply loss", loc="left")
    sh = {"MKT_BRENT": 0.9}
    b = [0.0] * n
    for k, v in sh.items(): b[idx[k]] = v
    s = b[:]; gain = [1 - r for r in web["res"]]
    frames = [s[:]]
    for _ in range(14):
        inf = [0.0] * n
        for (a, bb, w) in web["edges"]: inf[bb] += w * s[a]
        s = [(1 - 0.55) * s[i] + 0.55 * math.tanh(b[i] + gain[i] * inf[i])
             for i in range(n)]
        frames.append(s[:])
    for k in LAYER_ORDER:
        ids_k = [i for i, kk in enumerate(kinds) if kk == k]
        series = [np.mean([abs(f[i]) for i in ids_k]) for f in frames]
        ax.plot(range(len(frames)), series, lw=2.2, color=KC[k],
                label=KIND_LABEL[k], marker="o", ms=3.4)
    ax.set_xlabel("step"); ax.set_ylabel("average effect")
    ax.legend(frameon=False, fontsize=8.2, ncol=3)
    ax.grid(color=GRIDC, lw=0.7); ax.set_axisbelow(True)
    for sp in ("top", "right"): ax.spines[sp].set_visible(False)

    # ── E. reach matrix ─────────────────────────────────────────────────────
    ax = fig.add_subplot(gs[3, 2])
    ax.set_title("E.  Which changes reach which layers", loc="left")
    scen = list(M.SCEN.items())
    Mx = np.zeros((len(scen), len(LAYER_ORDER)))
    for i, (nm, shk) in enumerate(scen):
        if not all(k in idx for k in shk):
            continue
        st, _ = M.propagate(web, shk)
        for j, k in enumerate(LAYER_ORDER):
            ids_k = [q for q, kk in enumerate(kinds) if kk == k]
            Mx[i, j] = np.mean([abs(st[q]) for q in ids_k]) if ids_k else 0
    im = ax.imshow(Mx, cmap="YlOrBr", aspect="auto")
    ax.set_xticks(range(len(LAYER_ORDER)))
    ax.set_xticklabels([KIND_LABEL[k] for k in LAYER_ORDER], rotation=42,
                       ha="right", fontsize=7.6)
    ax.set_yticks(range(len(scen)))
    ax.set_yticklabels([s[0].replace("_", " ") for s in scen], fontsize=8)
    fig.colorbar(im, ax=ax, label="average effect", shrink=0.85)

    # ── F. the chain in words ───────────────────────────────────────────────
    ax = fig.add_subplot(gs[4, :]); ax.axis("off")
    ax.set_title("F.  The same chain, in words", loc="left")
    steps = [
        ("1", "The climate system holds carbon dioxide at 431 ppm and the "
              "temperature 1.19 C above the baseline.", "climate"),
        ("2", "Warming increases the risk of storms and heat waves. The model "
              "holds 526 recorded disasters with their real damages.", "event"),
        ("3", "Supply losses and demand changes move the price benchmarks. "
              "Each benchmark reacts at a speed set by its own history.", "market"),
        ("4", "Fuel prices pass into each country's fuel supply. The link is "
              "stronger where that fuel supplies more of the power.", "supply"),
        ("5", "Grids feel the cost of the fuels they use. 4,000 real plants "
              "carry the effect for the United States.", "grid"),
        ("6", "Grids deliver power to districts. District size follows the real "
              "national demand.", "district"),
        ("7", "Households and industry receive the cost. They reduce use, and "
              "the reduction returns to the grid as a negative link.", "consumer"),
        ("8", "Behaviour decides how much they reduce. Habit, loss aversion, "
              "status and social norms set the size of the response.", "psych"),
    ]
    yy = 0.94
    for num, text, k in steps:
        ax.add_patch(FancyBboxPatch((0.004, yy - 0.085), 0.028, 0.075,
                                    boxstyle="round,pad=0.004", lw=0,
                                    facecolor=KC[k]))
        ax.text(0.018, yy - 0.048, num, ha="center", va="center", fontsize=10,
                color="white", fontweight="bold")
        ax.text(0.042, yy - 0.048, text, va="center", fontsize=10.2)
        yy -= 0.118
    ax.set_xlim(0, 1); ax.set_ylim(0, 1)

    fig.text(0.045, 0.012,
             "Path strength is the product of the link weights along the route. "
             "A higher value means more of the change survives to the end.",
             fontsize=8.6, color=DIM)

    p = os.path.join(OUT, "energy_model_throughlines.png")
    fig.savefig(p, dpi=170, facecolor="white", bbox_inches="tight")
    fig.savefig(p.replace(".png", ".svg"), facecolor="white", bbox_inches="tight")
    plt.close(fig)
    print("wrote", p)


if __name__ == "__main__":
    main()
