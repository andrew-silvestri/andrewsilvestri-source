# The model in Julia, built from real data

Every procedural assumption is gone. The graph is now constructed from the
11.5 GB of feedstocks in `../16 Presentation Architecture/feedstocks/`.

## Run it

```
python3 calibrate/extract_calibration.py      # once, ~1 min (already run)
julia run.jl
```

No packages. No VS Code. See `SETUP_NO_VSCODE.md` if `julia` is not on your PATH.

## What the model is made of now

| Layer | Count | Source, not a guess |
|---|---|---|
| markets | 6 | FRED daily histories; each node's inertia is set by that series' own observed volatility |
| climate | 2 | NOAA Mauna Loa CO2 (820 months) and NASA GISTEMP (146 years) |
| grids | 214 | Real national electricity demand (EI Statistical Review + OWID) |
| fuel supplies | 725 | Real per-fuel share of each country's electricity; the share sets the edge weight |
| districts | 571 | Sized as shares of real national demand |
| consumers | 1,142 | Sized from real demand; elasticities cited from the literature |
| **events** | **526** | **Real EM-DAT disasters; severity from adjusted damages** |
| stations | 4,000 | Real US plants with coordinates from the EIA bulk archive |
| psych | 6 | Placed on real Allen Brain Atlas structures |
| **total** | **7,192 nodes / 13,824 edges** | |

Raise `max_plants` in `load_model` to add more of the 15,247 real plants.

## Verify the port

A Python mirror of the identical build and engine is in
`calibrate/verify_parity.py`. Run both and compare:

```
python3 calibrate/verify_parity.py
julia run.jl
```

The parity target is saved in `calibrate/out/parity_target.json`:

| scenario | nodes changed | top impacts |
|---|---|---|
| oil_supply_shock | 582 | MKT_GASOLINE, MKT_WTI, oil supplies |
| gas_price_spike | 294 | gas-dependent national supplies |
| climate_forcing | 1,313 | GLOBAL_TEMP, then every grid |
| us_grid_stress | 19 | US districts |
| china_coal_cut | 8 | GRID_CHN, Chinese districts |
| behaviour_shift | 7 | household consumers |

## Files

- `run.jl` — the only entry point.
- `src/EnergyWeb.jl` — the whole model: CSV reader, calibration loader, graph
  builder, engine, scenarios, provenance report.
- `calibrate/extract_calibration.py` — turns 11.5 GB of feedstocks into the
  compact tables in `calibrate/out/`.
- `calibrate/verify_parity.py` — the Python mirror used to verify the port.
- `SETUP_NO_VSCODE.md` — how to run it without the VS Code extension.

## Honest notes

- Scenario shocks are still applied as unitless stress. Converting stress to
  dollars per MWh is the next calibration step; the price histories needed for
  it are already loaded.
- Consumer elasticities are literature values, not fitted to your data. They are
  the last remaining assumed parameters, and they are labelled as such in the
  provenance report.
- `max_plants` defaults to 4,000 for a fast build. The extractor found 15,247
  real US plants with coordinates.
