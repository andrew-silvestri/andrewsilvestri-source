# Running the Julia model without VS Code

VS Code's Julia extension is the most common failure point in a Julia setup: the
language server can hang, and the extension can fail to find the Julia binary.
You do not need it. The model uses **only the Julia standard library**, so there
is no package installation step that can break.

## The one command

Open PowerShell (or Command Prompt) in this folder and run:

```
julia run.jl
```

That builds the model from the calibrated data and runs two demo scenarios.

If `julia` is not recognised, use the full path once:

```
"C:\Users\dasil\AppData\Local\Programs\Julia-1.11.5\bin\julia.exe" run.jl
```

To make `julia` work everywhere, install with `winget install julialang.juliaup`,
then open a new terminal. Juliaup puts `julia` on your PATH and manages versions.

## Other ways to run it (all better than VS Code for this)

| Option | Command | When to use |
|---|---|---|
| **Terminal REPL** | `julia` then `include("run.jl")` | Fastest. `web` stays in scope for exploring. |
| **Pluto notebook** | `julia -e "using Pkg; Pkg.add(\"Pluto\"); using Pluto; Pluto.run()"` | Browser-based, reactive, no editor needed. Good for a visual write-up. |
| **Jupyter** | `julia -e "using Pkg; Pkg.add(\"IJulia\")"` then `jupyter lab` | If you already use Jupyter for Python. |
| **Script** | `julia run.jl oil_supply_shock` | Run one scenario, print, exit. |

## Commands inside the REPL

```julia
include("run.jl")                # builds; `web` is now defined

s, hit = propagate(web, Dict("MKT_BRENT" => 1.0))
top(web, s, hit; k = 25)
layer_summary(web, s)
calibration_report(web)          # where every parameter came from

run_scenario(web, "climate_forcing")
keys(scenarios(web))             # list all scenarios
```

## If something still fails

1. `julia --version` — confirms Julia itself runs. If this fails, the install is
   the problem, not the model.
2. `julia -e "println(1+1)"` — confirms Julia can execute code.
3. `julia run.jl` from **this** folder — the model finds its data by relative
   path, so the working directory matters.
4. If it reports a missing calibration folder, run this first:
   `python3 calibrate/extract_calibration.py`

## Why the earlier attempt broke at step 2

`SETUP_PLAN.md` told you to `include("loader.jl")` before `include("engine.jl")`,
but `loader.jl` used the `Web` type that `engine.jl` defined. Include order
mattered, and the order given was wrong. Both files are now deleted. Everything
is in `src/EnergyWeb.jl` as one module, and `run.jl` is the only entry point,
so the problem cannot happen again.
