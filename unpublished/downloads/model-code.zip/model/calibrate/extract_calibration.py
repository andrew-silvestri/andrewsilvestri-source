"""
Turn the 11.5 GB of feedstocks into compact, verified calibration tables that
replace every procedural assumption in the model.

Reads (streaming, memory-safe) from ../../16 Presentation Architecture/feedstocks:
  ei_review/       -> national fuel mix + electricity demand, per country per year
  countries_demography/ -> population, GDP/cap, urbanisation, energy per capita
  eia_bulk/        -> real US plants with coordinates and net generation
  markets_finance/ -> real price histories for the units layer
  disasters/       -> real event catalogue (dates, coordinates, damages)
  agriculture/     -> real fertilizer + diet series
  climate/         -> real CO2, temperature, ENSO
  mind/            -> real brain structure ids for the psych layer

Writes ./out/*.csv plus calibration.json (small; the Julia core reads these).
Run:  python3 extract_calibration.py [--quick]
"""
import os, sys, csv, json, gzip, math, time
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
FEED = os.path.abspath(os.path.join(HERE, "..", "..",
                                    "16 Presentation Architecture", "feedstocks"))
OUT = os.path.join(HERE, "out")
os.makedirs(OUT, exist_ok=True)
QUICK = "--quick" in sys.argv
LOG = []


def note(k, v):
    LOG.append((k, v)); print(f"  {k}: {v}")


def w(name, header, rows):
    p = os.path.join(OUT, name)
    with open(p, "w", newline="", encoding="utf8") as f:
        cw = csv.writer(f); cw.writerow(header); cw.writerows(rows)
    return p


# ─────────────────────────────────────────────── 1. country fuel mix + demand
FUEL_VARS = {"electbyfuel_coal": "coal", "electbyfuel_gas": "gas",
             "electbyfuel_oil": "oil", "electbyfuel_nuclear": "nuclear",
             "electbyfuel_hydro": "hydro", "electbyfuel_ren_power": "renew",
             "electbyfuel_other": "other"}
EXTRA_VARS = {"elect_twh": "elect_twh", "solar_twh": "solar_twh",
              "wind_twh": "wind_twh", "co2_mtco2": "co2_mt",
              "primary_ej": "primary_ej", "gas_tes_ej": "gas_ej",
              "coal_tes_ej": "coal_ej", "oil_tes_ej": "oil_ej"}


def country_mix():
    src = os.path.join(FEED, "ei_review", "ei_statistical_review_tidy.csv")
    latest = defaultdict(dict)          # iso3 -> var -> (year, value)
    hist = defaultdict(list)            # (iso3, var) -> [(year, value)]
    with open(src, encoding="utf8", errors="ignore") as f:
        for row in csv.DictReader(f):
            var = row["Var"]
            if var not in FUEL_VARS and var not in EXTRA_VARS:
                continue
            iso = row["ISO3166_alpha3"]
            if not iso or len(iso) != 3:
                continue
            try:
                yr = int(row["Year"]); val = float(row["Value"] or 0)
            except ValueError:
                continue
            key = FUEL_VARS.get(var) or EXTRA_VARS[var]
            hist[(iso, key)].append((yr, val))
            prev = latest[iso].get(key)
            if prev is None or yr > prev[0]:
                latest[iso][key] = (yr, val)
    rows = []
    for iso, d in sorted(latest.items()):
        tot = sum(d[k][1] for k in FUEL_VARS.values() if k in d) or 0.0
        if tot <= 0:
            continue
        shares = {k: (d[k][1] / tot if k in d else 0.0) for k in FUEL_VARS.values()}
        yr = max(v[0] for v in d.values())
        rows.append([iso, yr,
                     round(shares["coal"], 5), round(shares["gas"], 5),
                     round(shares["oil"], 5), round(shares["nuclear"], 5),
                     round(shares["hydro"], 5), round(shares["renew"], 5),
                     round(shares["other"], 5),
                     round(d.get("elect_twh", (yr, 0))[1], 3),
                     round(d.get("elect_twh", (yr, 0))[1] / 8.76, 4),   # avg GW
                     round(d.get("co2_mt", (yr, 0))[1], 2),
                     round(d.get("primary_ej", (yr, 0))[1], 4)])
    # EI covers the majors; fill every remaining country from the OWID panel,
    # which carries per-fuel electricity shares for ~200 countries.
    have = {r[0] for r in rows}
    op = os.path.join(FEED, "countries_demography", "owid-energy-data.csv")
    best = {}
    with open(op, encoding="utf8", errors="ignore") as f:
        for r in csv.DictReader(f):
            iso = (r.get("iso_code") or "").strip()
            if len(iso) != 3 or iso in have:
                continue
            def g(k):
                try:
                    return float(r.get(k) or "")
                except ValueError:
                    return None
            shares = {k: g(f"{k}_share_elec") for k in
                      ("coal", "gas", "oil", "nuclear", "hydro")}
            ren = g("renewables_share_elec")
            if shares["coal"] is None and ren is None:
                continue
            try:
                yr = int(r["year"])
            except ValueError:
                continue
            if iso in best and best[iso][0] >= yr:
                continue
            dem = g("electricity_demand")            # TWh
            best[iso] = (yr, shares, ren, dem, g("co2") or 0.0,
                         g("primary_energy_consumption") or 0.0)
    added = 0
    for iso, (yr, sh, ren, dem, co2, prim) in sorted(best.items()):
        v = {k: (sh[k] or 0.0) / 100.0 for k in sh}
        renv = (ren or 0.0) / 100.0
        # OWID's renewables share includes hydro; keep them separate here
        renv = max(renv - v["hydro"], 0.0)
        tot = sum(v.values()) + renv
        if tot <= 0.05:
            continue
        norm = lambda x: round(x / tot, 5)
        rows.append([iso, yr, norm(v["coal"]), norm(v["gas"]), norm(v["oil"]),
                     norm(v["nuclear"]), norm(v["hydro"]), norm(renv),
                     round(max(0.0, 1 - sum(map(norm, list(v.values()) + [renv]))), 5),
                     round(dem or 0.0, 3), round((dem or 0.0) / 8.76, 4),
                     round(co2 / 1e6 if co2 > 1e5 else co2, 2), round(prim / 277.8, 4)])
        added += 1
    rows.sort(key=lambda r: r[0])
    w("country_mix.csv",
      ["iso3", "year", "coal", "gas", "oil", "nuclear", "hydro", "renew", "other",
       "elect_twh", "demand_gw_avg", "co2_mt", "primary_ej"], rows)
    note("country_mix", f"{len(rows)} countries with real fuel shares "
                        f"({len(have)} from EI + {added} from OWID)")
    # long history for the trend engines
    hrows = []
    for (iso, key), series in hist.items():
        if key not in ("elect_twh", "co2_mt", "primary_ej"):
            continue
        for yr, val in sorted(series):
            hrows.append([iso, key, yr, round(val, 4)])
    w("country_history.csv", ["iso3", "var", "year", "value"], hrows)
    note("country_history", f"{len(hrows):,} country-year points")
    return {r[0]: r for r in rows}


# ─────────────────────────────────────────────── 2. real US plants (EIA bulk)
def plants():
    src = os.path.join(FEED, "eia_bulk", "eia_ELEC_series.csv")
    rows = []
    seen = set()
    with open(src, encoding="utf8", errors="ignore") as f:
        for r in csv.DictReader(f):
            sid = r["series_id"]
            if not sid.startswith("ELEC.PLANT.GEN."):
                continue
            if not sid.endswith(".A"):          # annual series only
                continue
            body = sid[len("ELEC.PLANT.GEN."):-2]
            parts = body.split("-")
            if len(parts) < 3:
                continue
            pid, fuel, mover = parts[0], parts[1], parts[2]
            if fuel != "ALL" or mover != "ALL":  # one row per plant
                continue
            if pid in seen:
                continue
            seen.add(pid)
            lat, lon = r.get("lat", ""), r.get("lon", "")
            if not lat or not lon:
                continue
            name = r["name"].split(":")[1].strip() if ":" in r["name"] else r["name"]
            rows.append([pid, name[:70], lat, lon, r.get("iso3166", ""), r.get("units", "")])
    w("us_plants.csv", ["plant_id", "name", "lat", "lon", "state", "units"], rows)
    note("us_plants", f"{len(rows):,} real US plants with coordinates")
    return len(rows)


def plant_fuel_and_output():
    """Fuel type + latest annual net generation per plant, from the fuel-specific
    series (…GEN.<id>-<FUEL>-ALL.A) joined to the observations file."""
    src = os.path.join(FEED, "eia_bulk", "eia_ELEC_series.csv")
    fuel_of = {}
    with open(src, encoding="utf8", errors="ignore") as f:
        for r in csv.DictReader(f):
            sid = r["series_id"]
            if not sid.startswith("ELEC.PLANT.GEN.") or not sid.endswith(".A"):
                continue
            body = sid[len("ELEC.PLANT.GEN."):-2].split("-")
            if len(body) < 3 or body[1] == "ALL":
                continue
            fuel_of.setdefault(body[0], set()).add(body[1])
    obs_p = os.path.join(FEED, "eia_bulk", "eia_ELEC_observations.csv")
    latest = {}
    if os.path.exists(obs_p) and not QUICK:
        t0 = time.time()
        with open(obs_p, encoding="utf8", errors="ignore") as f:
            rd = csv.reader(f); next(rd, None)
            for sid, period, value in rd:
                if not sid.startswith("ELEC.PLANT.GEN.") or not sid.endswith("-ALL-ALL.A"):
                    continue
                pid = sid[len("ELEC.PLANT.GEN."):-len("-ALL-ALL.A")]
                try:
                    yr = int(str(period)[:4]); val = float(value)
                except (ValueError, TypeError):
                    continue
                cur = latest.get(pid)
                if cur is None or yr > cur[0]:
                    latest[pid] = (yr, val)
                if time.time() - t0 > 900:      # hard stop for very slow disks
                    break
    rows = []
    for pid, fuels in fuel_of.items():
        yr, mwh = latest.get(pid, ("", ""))
        rows.append([pid, "|".join(sorted(fuels)), yr, mwh])
    w("us_plant_fuels.csv", ["plant_id", "fuels", "latest_year", "net_gen_mwh"], rows)
    note("us_plant_fuels", f"{len(rows):,} plants typed"
                           f"{'' if latest else ' (generation skipped: --quick)'}")


# ─────────────────────────────────────────────── 3. prices for the units layer
def prices():
    out = []
    stats = {}
    d = os.path.join(FEED, "markets_finance")
    for fn in sorted(os.listdir(d)):
        if not fn.startswith("fred_") or not fn.endswith(".csv"):
            continue
        name = fn[5:-4]
        vals = []
        with open(os.path.join(d, fn), encoding="utf8", errors="ignore") as f:
            for r in csv.DictReader(f):
                try:
                    v = float(r["value"])
                except (ValueError, TypeError, KeyError):
                    continue
                vals.append((r["date"], v))
                out.append([name, r["date"], v])
        if vals:
            ys = [v for _, v in vals]
            ys_sorted = sorted(ys)
            stats[name] = dict(
                n=len(ys), start=vals[0][0], end=vals[-1][0],
                last=ys[-1], median=ys_sorted[len(ys) // 2],
                p95=ys_sorted[int(len(ys) * 0.95)], max=max(ys),
                spike_ratio=round(ys_sorted[int(len(ys) * 0.99)] / max(ys_sorted[len(ys)//2], 1e-9), 3))
    w("prices_long.csv", ["series", "date", "value"], out)
    note("prices", f"{len(stats)} series, {len(out):,} observations")
    return stats


# ─────────────────────────────────────────────── 4. real historical events
DIS_ENERGY = {"Storm", "Extreme temperature", "Flood", "Drought", "Wildfire",
              "Earthquake"}


def disasters():
    src = os.path.join(FEED, "disasters", "emdat_disasters.csv")
    rows = []
    with open(src, encoding="utf8", errors="ignore") as f:
        for r in csv.DictReader(f):
            try:
                yr = int(r.get("Start Year") or 0)
            except ValueError:
                continue
            if yr < 1965:
                continue
            dtype = (r.get("Disaster Type") or "").strip()
            if dtype not in DIS_ENERGY:
                continue
            def num(k):
                try:
                    return float(r.get(k) or 0)
                except ValueError:
                    return 0.0
            rows.append([r.get("DisNo."), yr, r.get("Start Month") or "",
                         dtype, r.get("Disaster Subtype") or "",
                         r.get("ISO") or "", r.get("Country") or "",
                         r.get("Latitude") or "", r.get("Longitude") or "",
                         num("Total Deaths"), num("Total Affected"),
                         num("Total Damage, Adjusted ('000 US$)")])
    rows.sort(key=lambda x: -x[11])
    w("events_energy_relevant.csv",
      ["id", "year", "month", "type", "subtype", "iso3", "country", "lat", "lon",
       "deaths", "affected", "damage_k_usd_adj"], rows)
    note("events", f"{len(rows):,} energy-relevant disasters since 1965; "
                   f"largest = {rows[0][6]} {rows[0][3]} {rows[0][1]}")
    return rows[:200]


# ─────────────────────────────────────────────── 5. agriculture + diets
def agriculture():
    made = []
    fert = os.path.join(FEED, "agriculture", "faostat_fertilizer.csv")
    if os.path.exists(fert):
        agg = defaultdict(float)
        with open(fert, encoding="utf8", errors="ignore") as f:
            for r in csv.DictReader(f):
                item = (r.get("Item") or "")
                if "nitrogen" not in item.lower():
                    continue
                el = (r.get("Element") or "").lower()
                if not ("agricultural use" in el or "production" in el):
                    continue
                try:
                    yr = int(r.get("Year") or 0); v = float(r.get("Value") or 0)
                except ValueError:
                    continue
                agg[(r.get("Area Code (M49)") or r.get("Area"), yr)] += v
        rows = [[k[0], k[1], round(v, 3)] for k, v in sorted(agg.items())]
        w("fertilizer_nitrogen.csv", ["area", "year", "tonnes_n"], rows)
        note("fertilizer", f"{len(rows):,} area-year nitrogen points"); made.append("fert")
    fb = os.path.join(FEED, "agriculture", "faostat_food_balances.csv")
    if os.path.exists(fb) and not QUICK:
        meat = defaultdict(float)
        with open(fb, encoding="utf8", errors="ignore") as f:
            for r in csv.DictReader(f):
                item = (r.get("Item") or "")
                if item not in ("Meat", "Meat, Other", "Bovine Meat", "Pigmeat",
                                "Poultry Meat", "Mutton & Goat Meat"):
                    continue
                if (r.get("Element") or "") != "Food supply quantity (kg/capita/yr)":
                    continue
                try:
                    yr = int(r.get("Year") or 0); v = float(r.get("Value") or 0)
                except ValueError:
                    continue
                meat[(r.get("Area"), yr)] += v
        rows = [[k[0], k[1], round(v, 2)] for k, v in sorted(meat.items())]
        w("diet_meat_kg_per_capita.csv", ["area", "year", "kg_per_capita"], rows)
        note("diets", f"{len(rows):,} area-year meat points"); made.append("diet")
    return made


# ─────────────────────────────────────────────── 6. climate
def climate():
    made = {}
    c = os.path.join(FEED, "climate", "02_noaa_co2_mauna_loa_monthly.csv")
    if os.path.exists(c):
        rows = []
        for line in open(c, encoding="utf8", errors="ignore"):
            if line.startswith("#"):
                continue
            t = [x.strip() for x in line.split(",")]
            if len(t) >= 4 and t[0].isdigit():
                try:
                    rows.append([int(t[0]), int(t[1]), float(t[3])])
                except ValueError:
                    pass
        w("co2_monthly.csv", ["year", "month", "ppm"], rows)
        made["co2"] = len(rows); note("co2", f"{len(rows)} months, last={rows[-1][2]} ppm")
    g = os.path.join(FEED, "climate", "02_nasa_gistemp_global.csv")
    if os.path.exists(g):
        rows = []
        for line in open(g, encoding="utf8", errors="ignore"):
            t = [x.strip() for x in line.split(",")]
            if t and t[0].isdigit() and len(t) > 13:
                try:
                    rows.append([int(t[0]), float(t[13])])
                except ValueError:
                    pass
        w("temp_anomaly_annual.csv", ["year", "anomaly_c"], rows)
        made["temp"] = len(rows)
        note("temp", f"{len(rows)} years, last={rows[-1][1]} C")
    o = os.path.join(FEED, "climate", "noaa_oni_enso.csv")
    if os.path.exists(o):
        rows = [r for r in csv.reader(open(o))][1:]
        w("enso_oni.csv", ["season", "year", "total", "anom"], rows)
        made["enso"] = len(rows); note("enso", f"{len(rows)} seasons")
    return made


# ─────────────────────────────────────────────── 7. demography + mind
def demography():
    p = os.path.join(FEED, "countries_demography", "owid-energy-data.csv")
    keep = ["country", "iso_code", "year", "population", "gdp",
            "energy_per_capita", "electricity_demand", "fossil_share_elec",
            "renewables_share_elec", "nuclear_share_elec", "carbon_intensity_elec",
            "per_capita_electricity", "energy_per_gdp"]
    rows = []
    with open(p, encoding="utf8", errors="ignore") as f:
        rd = csv.DictReader(f)
        have = [k for k in keep if k in rd.fieldnames]
        for r in rd:
            if not r.get("iso_code"):
                continue
            try:
                if int(r["year"]) < 1965:
                    continue
            except ValueError:
                continue
            rows.append([r.get(k, "") for k in have])
    w("owid_panel.csv", have, rows)
    note("owid_panel", f"{len(rows):,} country-year rows, {len(have)} variables")


def mind():
    p = os.path.join(FEED, "mind", "allen_brain_structures.csv")
    if not os.path.exists(p):
        return
    want = {"CTXpl": "present_bias", "ACAd": "dissonance", "BLA": "loss_aversion",
            "STRd": "habit", "ACB": "status", "TEa": "norm"}
    rows = []
    for r in csv.DictReader(open(p, encoding="utf8", errors="ignore")):
        if r["acronym"] in want:
            rows.append([want[r["acronym"]], r["id"], r["acronym"], r["name"],
                         r["depth"], r["color"]])
    w("psych_anatomy.csv",
      ["channel", "structure_id", "acronym", "name", "depth", "color"], rows)
    note("psych_anatomy", f"{len(rows)} channels matched to real structures")


# ─────────────────────────────────────────────── main
if __name__ == "__main__":
    t0 = time.time()
    print("reading feedstocks from", FEED)
    mix = country_mix()
    plants()
    plant_fuel_and_output()
    pstats = prices()
    ev = disasters()
    agriculture()
    cl = climate()
    demography()
    mind()
    manifest = dict(
        generated=time.strftime("%Y-%m-%d %H:%M:%S"),
        seconds=round(time.time() - t0, 1),
        countries_with_real_mix=len(mix),
        price_series=pstats,
        climate=cl,
        log=[{"item": k, "detail": v} for k, v in LOG],
        files=sorted(os.listdir(OUT)),
    )
    json.dump(manifest, open(os.path.join(OUT, "calibration.json"), "w"), indent=2)
    print(f"\ncalibration written to {OUT} in {manifest['seconds']}s")
