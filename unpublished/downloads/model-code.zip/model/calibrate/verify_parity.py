"""
Python mirror of src/EnergyWeb.jl — same build rules, same engine.
Run this, then run `julia run.jl`. The numbers must match.

    python3 verify_parity.py            # build + demo scenarios
    python3 verify_parity.py --json      # machine-readable parity target
"""
import os, csv, json, math, sys
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
CAL = os.path.join(HERE, "out")
FUELS = ("coal", "gas", "oil", "nuclear", "hydro", "renew")


def read(name):
    p = os.path.join(CAL, name)
    if not os.path.exists(p):
        return []
    with open(p, encoding="utf8", errors="ignore") as f:
        return list(csv.DictReader(f))


def num(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return 0.0


def build(max_plants=4000, districts_per_country=6):
    mix = {r["iso3"]: r for r in read("country_mix.csv")}
    plants = read("us_plants.csv")
    prices = defaultdict(list)
    for r in read("prices_long.csv"):
        prices[r["series"]].append(num(r["value"]))
    co2 = read("co2_monthly.csv")
    temp = read("temp_anomaly_annual.csv")
    psych = {r["channel"]: r for r in read("psych_anatomy.csv")}

    ids, names, kinds, res, prov = [], [], [], [], []
    idx = {}
    E = []

    def node(nid, name, kind, resil=0.35, source=""):
        if nid in idx:
            return
        idx[nid] = len(ids)
        ids.append(nid); names.append(name); kinds.append(kind)
        res.append(resil); prov.append(source)

    def edge(a, b, w):
        if a in idx and b in idx and abs(w) > 1e-6:
            E.append((idx[a], idx[b], w))

    price_meta = {"MKT_BRENT": ("brent", "Brent crude"),
                  "MKT_WTI": ("wti", "WTI crude"),
                  "MKT_HH": ("henry_hub", "Henry Hub gas"),
                  "MKT_GASOLINE": ("us_gasoline_retail", "US retail gasoline"),
                  "MKT_ELEC_RETAIL": ("elec_price_kwh", "US retail electricity"),
                  "MKT_CPI": ("cpi", "Consumer price index")}
    for mid, (series, label) in price_meta.items():
        v = [x for x in prices.get(series, []) if x > 0]
        if len(v) > 30:
            mean = sum(v) / len(v)
            var = sum((x - mean) ** 2 for x in v) / (len(v) - 1)
            vol = min(max(math.sqrt(var) / max(mean, 1e-9), 0.05), 0.9)
        else:
            vol = 0.3
        node(mid, label, "market", min(max(0.45 - vol / 2, 0.05), 0.45),
             f"FRED:{series} ({len(prices.get(series, []))} obs)")
    for a, b, w in (("MKT_BRENT", "MKT_WTI", 0.7), ("MKT_WTI", "MKT_BRENT", 0.7),
                    ("MKT_BRENT", "MKT_GASOLINE", 0.8),
                    ("MKT_HH", "MKT_ELEC_RETAIL", 0.35),
                    ("MKT_BRENT", "MKT_CPI", 0.15), ("MKT_HH", "MKT_CPI", 0.1)):
        edge(a, b, w)

    last_co2 = num(co2[-1]["ppm"]) if co2 else 0.0
    last_t = num(temp[-1]["anomaly_c"]) if temp else 0.0
    node("CLIMATE_SYS", f"Climate system (CO2 {round(last_co2,1)} ppm)", "climate",
         0.45, f"NOAA Mauna Loa, {len(co2)} months")
    node("GLOBAL_TEMP", f"Global temperature anomaly ({round(last_t,2)} C)",
         "climate", 0.55, f"NASA GISTEMP, {len(temp)} years")
    edge("CLIMATE_SYS", "GLOBAL_TEMP", 0.85)
    edge("GLOBAL_TEMP", "MKT_HH", 0.20)
    edge("GLOBAL_TEMP", "MKT_ELEC_RETAIL", 0.15)

    for iso in sorted(mix):
        m = mix[iso]
        dem = num(m["demand_gw_avg"])
        if dem <= 0:
            continue
        gid = f"GRID_{iso}"
        node(gid, f"{iso} grid ({round(dem,1)} GW avg)", "grid", 0.3,
             f"EI/OWID {m['year']}: {round(num(m['elect_twh']),1)} TWh")
        for f in FUELS:
            share = num(m[f])
            if share < 0.005:
                continue
            sid = f"SUP_{iso}_{f}"
            node(sid, f"{iso} {f} supply ({round(share*100,1)}% of power)", "supply",
                 0.35, f"EI/OWID {m['year']} fuel share")
            edge(sid, gid, 0.55 * share)
            if f in ("coal", "gas", "oil"):
                mk = "MKT_HH" if f == "gas" else "MKT_BRENT"
                edge(mk, sid, 0.35 + 0.4 * share)
        nd = min(max(round(math.sqrt(dem)), 2), districts_per_country)
        for k in range(1, nd + 1):
            did = f"DIS_{iso}_{k}"
            node(did, f"{iso} district {k}", "district", 0.35,
                 "share of real national demand")
            edge(gid, did, 0.6); edge(did, gid, 0.45 / nd)
            for tag, el in (("household", 0.45), ("industry", 0.35)):
                cid = f"CON_{iso}_{k}_{tag}"
                node(cid, f"{iso} district {k} {tag}", "consumer", 0.45,
                     "elasticity from literature; size from real demand")
                edge(did, cid, 0.5); edge(cid, did, -0.05 * el / 2)
        edge("GLOBAL_TEMP", gid, 0.30)

    events = read("events_energy_relevant.csv")
    byiso = defaultdict(list)
    for e in events:
        if e.get("iso3"): byiso[e["iso3"]].append(e)
    for iso, evs in byiso.items():
        if f"GRID_{iso}" not in idx: continue
        evs.sort(key=lambda e: -num(e["damage_k_usd_adj"]))
        for e in evs[:3]:
            dmg = num(e["damage_k_usd_adj"])
            if dmg <= 0: continue
            eid = f"EVENT_{e['id']}"
            node(eid, f"{e['country']} {e['type']} {e['year']} (${round(dmg/1000)}M damage)",
                 "event", 0.15, f"EM-DAT {e['id']}")
            sev = min(max(math.log10(max(dmg,1.0))/8.0, 0.05), 0.5)
            edge(eid, f"GRID_{iso}", sev)
            edge("GLOBAL_TEMP", eid, 0.12)

    usable = [p for p in plants if not (num(p["lat"]) == 0 and num(p["lon"]) == 0)]
    nplants = min(len(usable), max_plants)
    w_pg = 0.45 / nplants if nplants else 0.0
    for p in usable[:nplants]:
        pid = f"PLANT_{p['plant_id']}"
        node(pid, p["name"], "station", 0.45, "EIA bulk ELEC series")
        edge(pid, "GRID_USA", w_pg); edge("GRID_USA", pid, 0.05)

    for ch, a in psych.items():
        nid = f"PSYCH_{ch}"
        node(nid, f"{ch} ({a['acronym']}: {a['name']})", "psych", 0.75,
             f"Allen Brain Atlas structure {a['structure_id']}")
        edge("MKT_GASOLINE", nid, 0.25)
        for iso in ("USA", "CHN", "DEU", "IND", "GBR"):
            edge(nid, f"CON_{iso}_1_household", 0.12)

    return dict(ids=ids, names=names, kinds=kinds, res=res, prov=prov,
                idx=idx, edges=E)


def propagate(web, shocks, rounds=60, lam=0.55, thresh=0.02):
    n = len(web["ids"])
    b = [0.0] * n
    for k, v in shocks.items():
        i = web["idx"].get(k)
        if i is not None:
            b[i] = v
    s = b[:]
    hit = [-1] * n
    for i in range(n):
        if abs(s[i]) >= thresh:
            hit[i] = 0
    gain = [1.0 - r for r in web["res"]]
    for r in range(1, rounds + 1):
        inf = [0.0] * n
        for (src, dst, w) in web["edges"]:
            inf[dst] += w * s[src]
        sn = [0.0] * n
        mx = 0.0
        for i in range(n):
            sn[i] = (1 - lam) * s[i] + lam * math.tanh(b[i] + gain[i] * inf[i])
            if hit[i] < 0 and abs(sn[i]) >= thresh:
                hit[i] = r
            d = abs(sn[i] - s[i])
            if d > mx:
                mx = d
        s = sn
        if mx < 1e-5:
            break
    return [max(-1.0, min(1.0, x)) for x in s], hit


SCEN = {
    "oil_supply_shock": {"MKT_BRENT": 0.9},
    "gas_price_spike": {"MKT_HH": 0.85},
    "climate_forcing": {"CLIMATE_SYS": 0.8},
    "us_grid_stress": {"GRID_USA": 0.8},
    "china_coal_cut": {"SUP_CHN_coal": 0.8},
    "behaviour_shift": {"PSYCH_habit": -0.6, "PSYCH_norm": -0.6},
}

if __name__ == "__main__":
    web = build()
    n = len(web["ids"])
    print(f"model: {n} nodes, {len(web['edges'])} edges")
    from collections import Counter
    print("kinds:", dict(Counter(web["kinds"])))
    srcs = Counter(p.split(":")[0] if p else "(none)" for p in web["prov"])
    print("provenance:", dict(srcs))
    out = {"nodes": n, "edges": len(web["edges"]), "scenarios": {}}
    for name, sh in SCEN.items():
        if not all(k in web["idx"] for k in sh):
            print(f"  {name}: shock node missing, skipped"); continue
        s, hit = propagate(web, sh)
        touched = sum(1 for x in s if abs(x) >= 0.02)
        order = sorted(range(n), key=lambda i: -abs(s[i]))
        tops = [(web["ids"][i], round(s[i], 4), hit[i])
                for i in order[:8] if web["ids"][i] not in sh]
        out["scenarios"][name] = dict(touched=touched, top=tops)
        print(f"\n== {name}: {touched} of {n} nodes changed")
        for nid, val, h in tops[:6]:
            print(f"   {val:+.4f}  r{h:<3} {nid}")
    if "--json" in sys.argv:
        json.dump(out, open(os.path.join(CAL, "parity_target.json"), "w"), indent=2)
        print("\nwrote parity_target.json")
