# run.jl — the only entry point. No VS Code, no packages, no include order to get wrong.
#
#   julia run.jl                 build the model and run the demo
#   julia run.jl oil_supply_shock    run one scenario
#   julia run.jl --repl          build, then drop into an interactive session
#
# Uses only the Julia standard library. If it does not run, Julia itself is broken.

include(joinpath(@__DIR__, "src", "EnergyWeb.jl"))
using .EnergyWeb

function main()
    println("building the model from calibrated data ...")
    t = @elapsed web = load_model()
    println(web)
    @info "build time" seconds=round(t, digits=2)
    println()
    calibration_report(web)

    args = filter(a -> !startswith(a, "--"), ARGS)
    if isempty(args)
        println("\navailable scenarios: ", join(sort(collect(keys(scenarios(web)))), ", "))
        run_scenario(web, "oil_supply_shock")
        run_scenario(web, "climate_forcing")
    else
        for a in args
            run_scenario(web, a)
        end
    end

    if "--repl" in ARGS
        println("\nInteractive. `web` is loaded. Try:")
        println("  s, hit = propagate(web, Dict(\"MKT_BRENT\" => 1.0)); top(web, s, hit)")
        println("  layer_summary(web, s)")
        Base.active_repl === nothing && return web
    end
    web
end

web = main()
