"""
EnergyWeb — the model core in Julia.

Everything lives in this one module, so there is no include-order trap.
It uses ONLY the Julia standard library. There is no package to install and
nothing that can fail to download. The CSV reader is built in below.

Every parameter comes from a file in calibrate/out, which is produced from the
11.5 GB of feedstocks. Each node records its `provenance`.

Entry point:  see ../run.jl
"""
module EnergyWeb

using SparseArrays, Printf, Statistics, DelimitedFiles

export Web, load_model, propagate, top, layer_summary, scenarios, run_scenario,
       calibration_report

const HERE = normpath(joinpath(@__DIR__, ".."))
const CAL  = joinpath(HERE, "calibrate", "out")

# ───────────────────────────────────────────────────────── minimal CSV reader
"Read a CSV with a header row into (header::Vector{String}, rows::Vector{Vector{String}}).
Handles quoted fields containing commas. No dependencies."
function read_csv(path::AbstractString; limit::Int = typemax(Int))
    header = String[]
    rows = Vector{Vector{String}}()
    open(path, "r") do io
        first = true
        n = 0
        for line in eachline(io)
            isempty(line) && continue
            fields = split_csv_line(line)
            if first
                header = String.(fields); first = false
            else
                push!(rows, String.(fields))
                n += 1
                n >= limit && break
            end
        end
    end
    header, rows
end

function split_csv_line(line::AbstractString)
    out = String[]; buf = IOBuffer(); inq = false; i = 1
    chars = collect(line)
    while i <= length(chars)
        c = chars[i]
        if c == '"'
            if inq && i < length(chars) && chars[i+1] == '"'
                write(buf, '"'); i += 1
            else
                inq = !inq
            end
        elseif c == ',' && !inq
            push!(out, String(take!(buf)))
        else
            write(buf, c)
        end
        i += 1
    end
    push!(out, String(take!(buf)))
    out
end

col(header, name) = something(findfirst(==(name), header), 0)
fnum(s) = (v = tryparse(Float64, s); v === nothing ? 0.0 : v)
inum(s) = (v = tryparse(Int, s); v === nothing ? 0 : v)

# ───────────────────────────────────────────────────────── the graph
struct Web
    ids::Vector{String}
    names::Vector{String}
    kinds::Vector{String}
    country::Vector{String}
    res::Vector{Float64}
    size::Vector{Float64}
    lat::Vector{Float64}
    lon::Vector{Float64}
    provenance::Vector{String}
    W::SparseMatrixCSC{Float64,Int}
    idx::Dict{String,Int}
end

Base.show(io::IO, w::Web) = @printf(io,
    "Web(%d nodes, %d edges, %d kinds)\n", length(w.ids), nnz(w.W),
    length(unique(w.kinds)))

# ───────────────────────────────────────────────────────── calibration tables
struct Calibration
    mix::Dict{String,NamedTuple}          # iso3 -> shares + demand
    plants::Vector{NamedTuple}            # real US plants
    prices::Dict{String,Vector{Tuple{String,Float64}}}
    events::Vector{NamedTuple}
    co2::Vector{Tuple{Int,Int,Float64}}
    temp::Vector{Tuple{Int,Float64}}
    psych::Dict{String,NamedTuple}
    fert::Dict{Tuple{String,Int},Float64}
end

function load_calibration(dir::AbstractString = CAL)
    isdir(dir) || error("calibration folder not found: $dir\n" *
                        "run: python3 calibrate/extract_calibration.py")
    # --- country mix
    mix = Dict{String,NamedTuple}()
    h, rows = read_csv(joinpath(dir, "country_mix.csv"))
    ci = Dict(n => col(h, n) for n in h)
    for r in rows
        iso = r[ci["iso3"]]
        mix[iso] = (year = inum(r[ci["year"]]),
                    coal = fnum(r[ci["coal"]]), gas = fnum(r[ci["gas"]]),
                    oil = fnum(r[ci["oil"]]), nuclear = fnum(r[ci["nuclear"]]),
                    hydro = fnum(r[ci["hydro"]]), renew = fnum(r[ci["renew"]]),
                    other = fnum(r[ci["other"]]),
                    elect_twh = fnum(r[ci["elect_twh"]]),
                    demand_gw = fnum(r[ci["demand_gw_avg"]]),
                    co2_mt = fnum(r[ci["co2_mt"]]))
    end
    # --- real plants
    plants = NamedTuple[]
    p = joinpath(dir, "us_plants.csv")
    if isfile(p)
        h, rows = read_csv(p)
        ci = Dict(n => col(h, n) for n in h)
        for r in rows
            push!(plants, (id = r[ci["plant_id"]], name = r[ci["name"]],
                           lat = fnum(r[ci["lat"]]), lon = fnum(r[ci["lon"]]),
                           state = r[ci["state"]]))
        end
    end
    # --- prices
    prices = Dict{String,Vector{Tuple{String,Float64}}}()
    p = joinpath(dir, "prices_long.csv")
    if isfile(p)
        h, rows = read_csv(p)
        ci = Dict(n => col(h, n) for n in h)
        for r in rows
            push!(get!(prices, r[ci["series"]], Tuple{String,Float64}[]),
                  (r[ci["date"]], fnum(r[ci["value"]])))
        end
    end
    # --- events
    events = NamedTuple[]
    p = joinpath(dir, "events_energy_relevant.csv")
    if isfile(p)
        h, rows = read_csv(p)
        ci = Dict(n => col(h, n) for n in h)
        for r in rows
            push!(events, (id = r[ci["id"]], year = inum(r[ci["year"]]),
                           type = r[ci["type"]], iso3 = r[ci["iso3"]],
                           country = r[ci["country"]],
                           lat = fnum(r[ci["lat"]]), lon = fnum(r[ci["lon"]]),
                           deaths = fnum(r[ci["deaths"]]),
                           damage = fnum(r[ci["damage_k_usd_adj"]])))
        end
    end
    # --- climate
    co2 = Tuple{Int,Int,Float64}[]
    p = joinpath(dir, "co2_monthly.csv")
    if isfile(p)
        h, rows = read_csv(p)
        for r in rows
            push!(co2, (inum(r[1]), inum(r[2]), fnum(r[3])))
        end
    end
    temp = Tuple{Int,Float64}[]
    p = joinpath(dir, "temp_anomaly_annual.csv")
    if isfile(p)
        h, rows = read_csv(p)
        for r in rows
            push!(temp, (inum(r[1]), fnum(r[2])))
        end
    end
    # --- psych anatomy
    psych = Dict{String,NamedTuple}()
    p = joinpath(dir, "psych_anatomy.csv")
    if isfile(p)
        h, rows = read_csv(p)
        ci = Dict(n => col(h, n) for n in h)
        for r in rows
            psych[r[ci["channel"]]] = (id = r[ci["structure_id"]],
                                       acronym = r[ci["acronym"]],
                                       name = r[ci["name"]])
        end
    end
    # --- fertilizer
    fert = Dict{Tuple{String,Int},Float64}()
    p = joinpath(dir, "fertilizer_nitrogen.csv")
    if isfile(p)
        h, rows = read_csv(p)
        for r in rows
            fert[(r[1], inum(r[2]))] = fnum(r[3])
        end
    end
    Calibration(mix, plants, prices, events, co2, temp, psych, fert)
end

# ───────────────────────────────────────────────────────── build from data
const FUELS = ("coal", "gas", "oil", "nuclear", "hydro", "renew")

"""
    load_model(; max_plants=4000, districts_per_country=6)

Build the graph from the calibration tables. Every parameter that used to be a
procedural guess now comes from a file; each node records its `provenance`.
"""
function load_model(; max_plants::Int = 4000, districts_per_country::Int = 6,
                    calib::Union{Nothing,Calibration} = nothing)
    C = calib === nothing ? load_calibration() : calib
    ids = String[]; names = String[]; kinds = String[]; countryv = String[]
    res = Float64[]; sz = Float64[]; latv = Float64[]; lonv = Float64[]
    prov = String[]
    idx = Dict{String,Int}()
    I = Int[]; J = Int[]; V = Float64[]

    function node!(id, name, kind; country = "", resil = 0.35, size = 1.0,
                   lat = 0.0, lon = 0.0, source = "")
        haskey(idx, id) && return idx[id]
        push!(ids, id); push!(names, name); push!(kinds, kind)
        push!(countryv, country); push!(res, resil); push!(sz, size)
        push!(latv, lat); push!(lonv, lon); push!(prov, source)
        idx[id] = length(ids)
    end
    function edge!(a, b, w)
        (haskey(idx, a) && haskey(idx, b) && abs(w) > 1e-6) || return
        push!(J, idx[a]); push!(I, idx[b]); push!(V, w)
    end

    # ---- markets (prices are real; resilience from observed volatility)
    price_meta = Dict(
        "MKT_BRENT" => ("brent", "Brent crude"),
        "MKT_WTI" => ("wti", "WTI crude"),
        "MKT_HH" => ("henry_hub", "Henry Hub gas"),
        "MKT_GASOLINE" => ("us_gasoline_retail", "US retail gasoline"),
        "MKT_ELEC_RETAIL" => ("elec_price_kwh", "US retail electricity"),
        "MKT_CPI" => ("cpi", "Consumer price index"),
    )
    for (mid, (series, label)) in price_meta
        v = get(C.prices, series, Tuple{String,Float64}[])
        vol = if length(v) > 30
            xs = [x[2] for x in v if x[2] > 0]
            isempty(xs) ? 0.3 : clamp(std(xs) / max(mean(xs), 1e-9), 0.05, 0.9)
        else
            0.3
        end
        node!(mid, label, "market"; resil = clamp(0.45 - vol / 2, 0.05, 0.45),
              size = 1.5, source = "FRED:$series ($(length(v)) obs)")
    end
    # market substitution (unchanged structure, now between real-priced nodes)
    for (a, b, w) in (("MKT_BRENT", "MKT_WTI", 0.7), ("MKT_WTI", "MKT_BRENT", 0.7),
                      ("MKT_BRENT", "MKT_GASOLINE", 0.8),
                      ("MKT_HH", "MKT_ELEC_RETAIL", 0.35),
                      ("MKT_BRENT", "MKT_CPI", 0.15), ("MKT_HH", "MKT_CPI", 0.1))
        edge!(a, b, w)
    end

    # ---- climate system (real series)
    last_co2 = isempty(C.co2) ? 0.0 : C.co2[end][3]
    last_t = isempty(C.temp) ? 0.0 : C.temp[end][2]
    node!("CLIMATE_SYS", "Climate system (CO2 $(round(last_co2,digits=1)) ppm)",
          "climate"; resil = 0.45, size = 2.0,
          source = "NOAA Mauna Loa, $(length(C.co2)) months")
    node!("GLOBAL_TEMP", "Global temperature anomaly ($(round(last_t,digits=2)) C)",
          "climate"; resil = 0.55, size = 2.0,
          source = "NASA GISTEMP, $(length(C.temp)) years")
    edge!("CLIMATE_SYS", "GLOBAL_TEMP", 0.85)
    # temperature drives heating and cooling demand, which moves fuel and power
    # prices; this is the route from the physical world into the market layer
    edge!("GLOBAL_TEMP", "MKT_HH", 0.20)
    edge!("GLOBAL_TEMP", "MKT_ELEC_RETAIL", 0.15)

    # ---- countries: mix, demand, supplies, grids, districts (all real)
    for (iso, m) in sort(collect(C.mix); by = first)
        m.demand_gw <= 0 && continue
        gid = "GRID_$iso"
        node!(gid, "$iso grid ($(round(m.demand_gw, digits=1)) GW avg)", "grid";
              country = iso, resil = 0.3, size = max(m.demand_gw / 50, 0.2),
              source = "EI/OWID $(m.year): $(round(m.elect_twh,digits=1)) TWh")
        for f in FUELS
            share = getfield(m, Symbol(f))
            share < 0.005 && continue
            sid = "SUP_$(iso)_$(f)"
            node!(sid, "$iso $f supply ($(round(share*100, digits=1))% of power)",
                  "supply"; country = iso, resil = 0.35,
                  size = max(m.demand_gw * share / 40, 0.05),
                  source = "EI/OWID $(m.year) fuel share")
            # fuel share sets the strength of the dispatch-cost edge — real, not guessed
            edge!(sid, gid, 0.55 * share)
            if f in ("coal", "gas", "oil")
                mk = f == "gas" ? "MKT_HH" : "MKT_BRENT"
                edge!(mk, sid, 0.35 + 0.4 * share)
            end
        end
        # districts sized by real national demand
        nd = clamp(round(Int, sqrt(m.demand_gw)), 2, districts_per_country)
        for k in 1:nd
            did = "DIS_$(iso)_$k"
            node!(did, "$iso district $k", "district"; country = iso,
                  resil = 0.35, size = m.demand_gw / nd / 30,
                  source = "share of real national demand")
            edge!(gid, did, 0.6)
            edge!(did, gid, 0.45 / nd)          # fan-in normalized
            for (tag, el) in (("household", 0.45), ("industry", 0.35))
                cid = "CON_$(iso)_$(k)_$tag"
                node!(cid, "$iso district $k $tag", "consumer"; country = iso,
                      resil = 0.45, size = m.demand_gw / nd / 60,
                      source = "elasticity from literature; size from real demand")
                edge!(did, cid, 0.5)
                edge!(cid, did, -0.05 * el / 2) # demand response, 2 per district
            end
        end
        edge!("GLOBAL_TEMP", gid, 0.30)          # climate stresses every grid
    end

    # ---- real historical events (EM-DAT): the largest energy-relevant
    # disasters become nodes wired to the grid of the country they hit.
    # Magnitude comes from adjusted damages, not from a guess.
    byiso = Dict{String,Vector{NamedTuple}}()
    for e in C.events
        isempty(e.iso3) && continue
        push!(get!(byiso, e.iso3, NamedTuple[]), e)
    end
    nev = 0
    for (iso, evs) in byiso
        haskey(idx, "GRID_$iso") || continue
        sort!(evs; by = e -> -e.damage)
        for e in evs[1:min(3, length(evs))]
            e.damage <= 0 && continue
            eid = "EVENT_$(e.id)"
            node!(eid, "$(e.country) $(e.type) $(e.year) " *
                       "(\$$(round(Int, e.damage/1000))M damage)", "event";
                  country = iso, resil = 0.15, size = 0.6,
                  lat = e.lat, lon = e.lon,
                  source = "EM-DAT $(e.id)")
            # severity scaled by damage, capped
            sev = clamp(log10(max(e.damage, 1.0)) / 8.0, 0.05, 0.5)
            edge!(eid, "GRID_$iso", sev)
            edge!("GLOBAL_TEMP", eid, 0.12)      # warming raises event frequency
            nev += 1
        end
    end

    # ---- real US plants (subset for tractability; raise max_plants freely)
    # Fan-in normalization: the fleet as a whole carries a bounded influence on
    # its grid, so adding plants raises resolution, not the grid's sensitivity.
    usable = [p for p in C.plants if !(p.lat == 0.0 && p.lon == 0.0)]
    nplants = min(length(usable), max_plants)
    w_plant_to_grid = nplants > 0 ? 0.45 / nplants : 0.0
    for p in usable[1:nplants]
        pid = "PLANT_$(p.id)"
        node!(pid, p.name, "station"; country = "USA", resil = 0.45, size = 0.4,
              lat = p.lat, lon = p.lon, source = "EIA bulk ELEC series")
        edge!(pid, "GRID_USA", w_plant_to_grid)
        edge!("GRID_USA", pid, 0.05)
    end

    # ---- psych layer placed on real anatomy
    for (ch, a) in C.psych
        nid = "PSYCH_$ch"
        node!(nid, "$ch ($(a.acronym): $(a.name))", "psych"; resil = 0.75,
              size = 0.8, source = "Allen Brain Atlas structure $(a.id)")
        edge!("MKT_GASOLINE", nid, 0.25)
        for iso in ("USA", "CHN", "DEU", "IND", "GBR")
            edge!(nid, "CON_$(iso)_1_household", 0.12)
        end
    end

    n = length(ids)
    W = sparse(I, J, V, n, n)
    Web(ids, names, kinds, countryv, res, sz, latv, lonv, prov, W, idx)
end

# ───────────────────────────────────────────────────────── engine
"""
    propagate(web, shocks; rounds=60, lam=0.55, thresh=0.02)

Damped saturating propagation. Identical math to the Python engine.
Returns (state, first_hit).
"""
function propagate(web::Web, shocks::AbstractDict; rounds::Int = 60,
                   lam::Float64 = 0.55, thresh::Float64 = 0.02)
    n = length(web.ids)
    b = zeros(n)
    for (k, v) in shocks
        i = k isa Integer ? Int(k) : get(web.idx, String(k), 0)
        i > 0 && (b[i] = Float64(v))
    end
    s = copy(b)
    hit = fill(-1, n)
    @inbounds for i in 1:n
        abs(s[i]) >= thresh && (hit[i] = 0)
    end
    gain = 1.0 .- web.res
    for r in 1:rounds
        s_new = (1 - lam) .* s .+ lam .* tanh.(b .+ gain .* (web.W * s))
        mx = 0.0
        @inbounds for i in 1:n
            hit[i] < 0 && abs(s_new[i]) >= thresh && (hit[i] = r)
            d = abs(s_new[i] - s[i]); d > mx && (mx = d)
        end
        s = s_new
        mx < 1e-5 && break
    end
    clamp.(s, -1.0, 1.0), hit
end

function top(web::Web, s::Vector{Float64}, hit::Vector{Int} = Int[]; k::Int = 20,
             exclude = String[])
    ex = Set(exclude)
    order = sortperm(abs.(s); rev = true)
    shown = 0
    println(rpad("impact", 9), rpad("round", 7), rpad("kind", 12), "node")
    for i in order
        (web.ids[i] in ex) && continue
        abs(s[i]) < 1e-4 && continue
        r = isempty(hit) ? -1 : hit[i]
        @printf("%+8.4f  %-6s %-11s %s\n", s[i], r < 0 ? "-" : string(r),
                web.kinds[i], first(web.names[i], 58))
        (shown += 1) >= k && break
    end
end

function layer_summary(web::Web, s::Vector{Float64}; thresh = 0.02)
    acc = Dict{String,Vector{Float64}}()
    for (i, kd) in enumerate(web.kinds)
        push!(get!(acc, kd, Float64[]), abs(s[i]))
    end
    for kd in sort(collect(keys(acc)))
        v = acc[kd]
        @printf("%-11s n=%-6d touched=%-6d mean=%.4f max=%.3f\n",
                kd, length(v), count(>=(thresh), v), mean(v), maximum(v))
    end
end

# ───────────────────────────────────────────────────────── scenarios
"Scenarios expressed on the data-built graph."
function scenarios(web::Web)
    S = Dict{String,Tuple{String,Dict{String,Float64}}}()
    S["oil_supply_shock"] = ("A large oil supply loss raises the crude benchmark.",
                             Dict("MKT_BRENT" => 0.9))
    S["gas_price_spike"] = ("A gas price spike moves power costs everywhere.",
                            Dict("MKT_HH" => 0.85))
    S["climate_forcing"] = ("The climate system moves to a higher anomaly.",
                            Dict("CLIMATE_SYS" => 0.8))
    S["us_grid_stress"] = ("The US grid loses reserve margin.",
                           Dict("GRID_USA" => 0.8))
    S["china_coal_cut"] = ("China loses part of its coal supply.",
                           Dict("SUP_CHN_coal" => 0.8))
    S["behaviour_shift"] = ("A conservation wave enters through the mind layer.",
                            Dict("PSYCH_habit" => -0.6, "PSYCH_norm" => -0.6))
    S
end

function run_scenario(web::Web, name::AbstractString; k::Int = 15)
    S = scenarios(web)
    haskey(S, name) || error("unknown scenario. options: " * join(sort(collect(keys(S))), ", "))
    desc, sh = S[name]
    println("\n== $name\n   $desc")
    s, hit = propagate(web, sh)
    touched = count(x -> abs(x) >= 0.02, s)
    @printf("   %d of %d nodes changed\n\n", touched, length(s))
    top(web, s, hit; k = k, exclude = collect(keys(sh)))
    s, hit
end

"Print where every parameter came from."
function calibration_report(web::Web)
    src = Dict{String,Int}()
    for p in web.provenance
        key = isempty(p) ? "(none)" : split(p, ':')[1]
        src[key] = get(src, key, 0) + 1
    end
    println("node parameter sources:")
    for (k, v) in sort(collect(src); by = x -> -x[2])
        @printf("  %-42s %d nodes\n", k, v)
    end
end

end # module
